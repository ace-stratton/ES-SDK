/*!
********************************************************************************************
* @file FP_FSWGeneralProtocolServer.c
* @brief ESSA Stack server-side implementation
********************************************************************************************
* @version           interface FSWGeneral v0.1
*
* @copyright         (C) Copyright EnduroSat
*
*                    Contents and presentations are protected world-wide.
*                    Any kind of using, copying etc. is prohibited without prior permission.
*                    All rights - incl. industrial property rights - are reserved.
*
*-------------------------------------------------------------------------------------------
* GENERATOR: org.endurosat.generators.macchiato.binders.Gen_C v2.12
*-------------------------------------------------------------------------------------------
* !!! Please note that this code is fully GENERATED and shall not be manually modified as
* all changes will be overwritten !!!
********************************************************************************************
*/

#include "FP_FSWGeneralProtocolServer.h"
#include "FP_common/FP_ProtocolServerCommon.h"

#define FSWGeneral_PROTOCOL_VERSION_MAJOR   ((uint8_t) 0)
#define FSWGeneral_PROTOCOL_VERSION_MINOR   ((uint8_t) 1)

/**********************************************************************
 *
 *  Local type definitions
 *
 **********************************************************************/
typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    FSWGeneralsetInstrumentTimeRequestData_t data;
} PACKED_STRUCT FSWGeneralsetInstrumentTimeProtocolRequestData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    FSWGeneralsetInstrumentTimeResponseData_t data;
} PACKED_STRUCT FSWGeneralsetInstrumentTimeProtocolResponseData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    FSWGeneralsetInstrumentDateRequestData_t data;
} PACKED_STRUCT FSWGeneralsetInstrumentDateProtocolRequestData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    FSWGeneralsetInstrumentDateResponseData_t data;
} PACKED_STRUCT FSWGeneralsetInstrumentDateProtocolResponseData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
} PACKED_STRUCT FSWGeneralgetInstrumentTimeDateProtocolRequestData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    FSWGeneralgetInstrumentTimeDateResponseData_t data;
} PACKED_STRUCT FSWGeneralgetInstrumentTimeDateProtocolResponseData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
} PACKED_STRUCT FSWGeneralgetInstrumentModesProtocolRequestData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    FSWGeneralgetInstrumentModesResponseData_t data;
} PACKED_STRUCT FSWGeneralgetInstrumentModesProtocolResponseData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    FSWGeneralsetInstrumentModesRequestData_t data;
} PACKED_STRUCT FSWGeneralsetInstrumentModesProtocolRequestData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    FSWGeneralsetInstrumentModesResponseData_t data;
} PACKED_STRUCT FSWGeneralsetInstrumentModesProtocolResponseData_t;


/**********************************************************************
 *
 *  Static methods declarations
 *
 **********************************************************************/
static bool fs_HandleData(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo);
static void fs_setInstrumentTimeReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo);
static void fs_setInstrumentDateReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo);
static void fs_getInstrumentTimeDateReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo);
static void fs_getInstrumentModesReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo);
static void fs_setInstrumentModesReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo);

/**********************************************************************
 *
 *  Public variable definitions
 *
 **********************************************************************/
const ESSA_Stack_FunctionProtocolInfo_t FP_FSWGeneralProtocolServerInfo = {
    .u16ProtocolId    = ES_SAT_FUNC_PROTOCOL_ID_FSWGENERAL,
    .pfDataHandlerCbk = fs_HandleData
};

/**********************************************************************
 *
 *  Static variable definitions
 *
 **********************************************************************/
static FSWGeneral_ServerApi_t *pSrvApiHnd = NULL;

static const ProtocolFuncArrayEntry_t fs_aFuncArray[] = {
    { FSWGENERAL_SETINSTRUMENTTIME_FUNC_ID, fs_setInstrumentTimeReq },
    { FSWGENERAL_SETINSTRUMENTDATE_FUNC_ID, fs_setInstrumentDateReq },
    { FSWGENERAL_GETINSTRUMENTTIMEDATE_FUNC_ID, fs_getInstrumentTimeDateReq },
    { FSWGENERAL_GETINSTRUMENTMODES_FUNC_ID, fs_getInstrumentModesReq },
    { FSWGENERAL_SETINSTRUMENTMODES_FUNC_ID, fs_setInstrumentModesReq }
};

/**********************************************************************
 *
 *  Static methods implementation
 *
 **********************************************************************/
static bool fs_HandleData(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo)
{
    ESSA_Stack_FP_MsgHdr_t *pHdr = NULL;
    bool bIsFuncSupported = false;
    uint8_t i;

    // Basic header validity check
    if ((fp_DataInfo == NULL) ||
        (fp_DataInfo->u16DataSize < sizeof(ESSA_Stack_FP_MsgHdr_t)) ||
        (fp_DataInfo->pu8Data == NULL))
    {
        return false;
    }

    pHdr = (ESSA_Stack_FP_MsgHdr_t *) fp_DataInfo->pu8Data;

    if (IS_REQUEST(*pHdr))
    {
        for (i = 0; i < COUNT_OF(fs_aFuncArray); i++)
        {
            if (fs_aFuncArray[i].funcId == pHdr->funcId)
            {
                if (fs_aFuncArray[i].pfFunc != NULL)
                {
                    bIsFuncSupported = true;
                    fs_aFuncArray[i].pfFunc(fp_DataInfo);
                }

                break;
            }
        }

        if (!bIsFuncSupported)
            (void) ProtocolSendErrorResp(fp_DataInfo, (uint8_t) ESSA_FP_ERRCODE_FUNC_NOT_SUPPORTED);
    }

    return bIsFuncSupported;
}

static void fs_setInstrumentTimeReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo)
{
    FSWGeneralsetInstrumentTimeProtocolRequestData_t *fullrequest = (FSWGeneralsetInstrumentTimeProtocolRequestData_t *) fp_DataInfo->pu8Data;
    FSWGeneralsetInstrumentTimeRequestData_t *requestPayload = NULL;
    ReqContext_t requestCtx;

    STATIC_ASSERT_SIZE_CHECK(FSWGeneralsetInstrumentTimeProtocolRequestData_t);

    if ((fullrequest == NULL) || (pSrvApiHnd == NULL) || (fp_DataInfo->u16DataSize != sizeof(*fullrequest)))
    {
        return;
    }
#ifndef BIG_ENDIAN_PLATFORM
    requestPayload = (FSWGeneralsetInstrumentTimeRequestData_t *) &fullrequest->data;
#else   // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Deserialize response fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    if (pSrvApiHnd->FSWGeneral_setInstrumentTimeRequestHandler != NULL)
    {
        requestCtx.nInterfaceNumber = fp_DataInfo->pMACContext->nInterfaceNumber;
        requestCtx.netType = fp_DataInfo->pMACContext->netType;
        requestCtx.nAddr = fp_DataInfo->pMACContext->nSourceAddr;
        requestCtx.seqId = fullrequest->hdr.seqId;

        pSrvApiHnd->FSWGeneral_setInstrumentTimeRequestHandler(&requestCtx,
                                        requestPayload);
    }
}

static void fs_setInstrumentDateReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo)
{
    FSWGeneralsetInstrumentDateProtocolRequestData_t *fullrequest = (FSWGeneralsetInstrumentDateProtocolRequestData_t *) fp_DataInfo->pu8Data;
    FSWGeneralsetInstrumentDateRequestData_t *requestPayload = NULL;
    ReqContext_t requestCtx;

    STATIC_ASSERT_SIZE_CHECK(FSWGeneralsetInstrumentDateProtocolRequestData_t);

    if ((fullrequest == NULL) || (pSrvApiHnd == NULL) || (fp_DataInfo->u16DataSize != sizeof(*fullrequest)))
    {
        return;
    }
#ifndef BIG_ENDIAN_PLATFORM
    requestPayload = (FSWGeneralsetInstrumentDateRequestData_t *) &fullrequest->data;
#else   // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Deserialize response fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    if (pSrvApiHnd->FSWGeneral_setInstrumentDateRequestHandler != NULL)
    {
        requestCtx.nInterfaceNumber = fp_DataInfo->pMACContext->nInterfaceNumber;
        requestCtx.netType = fp_DataInfo->pMACContext->netType;
        requestCtx.nAddr = fp_DataInfo->pMACContext->nSourceAddr;
        requestCtx.seqId = fullrequest->hdr.seqId;

        pSrvApiHnd->FSWGeneral_setInstrumentDateRequestHandler(&requestCtx,
                                        requestPayload);
    }
}

static void fs_getInstrumentTimeDateReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo)
{
    FSWGeneralgetInstrumentTimeDateProtocolRequestData_t *fullrequest = (FSWGeneralgetInstrumentTimeDateProtocolRequestData_t *) fp_DataInfo->pu8Data;
    ReqContext_t requestCtx;

    STATIC_ASSERT_SIZE_CHECK(FSWGeneralgetInstrumentTimeDateProtocolRequestData_t);

    if ((fullrequest == NULL) || (pSrvApiHnd == NULL) || (fp_DataInfo->u16DataSize != sizeof(*fullrequest)))
    {
        return;
    }
#ifndef BIG_ENDIAN_PLATFORM
    // no out-arguments specified for response - simple acknowledge call
#else   // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Deserialize response fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    if (pSrvApiHnd->FSWGeneral_getInstrumentTimeDateRequestHandler != NULL)
    {
        requestCtx.nInterfaceNumber = fp_DataInfo->pMACContext->nInterfaceNumber;
        requestCtx.netType = fp_DataInfo->pMACContext->netType;
        requestCtx.nAddr = fp_DataInfo->pMACContext->nSourceAddr;
        requestCtx.seqId = fullrequest->hdr.seqId;

        pSrvApiHnd->FSWGeneral_getInstrumentTimeDateRequestHandler(&requestCtx);
    }
}

static void fs_getInstrumentModesReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo)
{
    FSWGeneralgetInstrumentModesProtocolRequestData_t *fullrequest = (FSWGeneralgetInstrumentModesProtocolRequestData_t *) fp_DataInfo->pu8Data;
    ReqContext_t requestCtx;

    STATIC_ASSERT_SIZE_CHECK(FSWGeneralgetInstrumentModesProtocolRequestData_t);

    if ((fullrequest == NULL) || (pSrvApiHnd == NULL) || (fp_DataInfo->u16DataSize != sizeof(*fullrequest)))
    {
        return;
    }
#ifndef BIG_ENDIAN_PLATFORM
    // no out-arguments specified for response - simple acknowledge call
#else   // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Deserialize response fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    if (pSrvApiHnd->FSWGeneral_getInstrumentModesRequestHandler != NULL)
    {
        requestCtx.nInterfaceNumber = fp_DataInfo->pMACContext->nInterfaceNumber;
        requestCtx.netType = fp_DataInfo->pMACContext->netType;
        requestCtx.nAddr = fp_DataInfo->pMACContext->nSourceAddr;
        requestCtx.seqId = fullrequest->hdr.seqId;

        pSrvApiHnd->FSWGeneral_getInstrumentModesRequestHandler(&requestCtx);
    }
}

static void fs_setInstrumentModesReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo)
{
    FSWGeneralsetInstrumentModesProtocolRequestData_t *fullrequest = (FSWGeneralsetInstrumentModesProtocolRequestData_t *) fp_DataInfo->pu8Data;
    FSWGeneralsetInstrumentModesRequestData_t *requestPayload = NULL;
    ReqContext_t requestCtx;

    STATIC_ASSERT_SIZE_CHECK(FSWGeneralsetInstrumentModesProtocolRequestData_t);

    if ((fullrequest == NULL) || (pSrvApiHnd == NULL) || (fp_DataInfo->u16DataSize != sizeof(*fullrequest)))
    {
        return;
    }
#ifndef BIG_ENDIAN_PLATFORM
    requestPayload = (FSWGeneralsetInstrumentModesRequestData_t *) &fullrequest->data;
#else   // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Deserialize response fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    if (pSrvApiHnd->FSWGeneral_setInstrumentModesRequestHandler != NULL)
    {
        requestCtx.nInterfaceNumber = fp_DataInfo->pMACContext->nInterfaceNumber;
        requestCtx.netType = fp_DataInfo->pMACContext->netType;
        requestCtx.nAddr = fp_DataInfo->pMACContext->nSourceAddr;
        requestCtx.seqId = fullrequest->hdr.seqId;

        pSrvApiHnd->FSWGeneral_setInstrumentModesRequestHandler(&requestCtx,
                                        requestPayload);
    }
}


/**********************************************************************
 *
 *  Public methods implementation
 *
 **********************************************************************/
void FSWGeneral_registerServerApi(FSWGeneral_ServerApi_t *pSrvApiHandlers)
{
    pSrvApiHnd = pSrvApiHandlers;
}

ESSA_pStack_FunctionProtocolInfo_t FSWGeneral_getServerProtocolDescriptor(void)
{
    return (ESSA_pStack_FunctionProtocolInfo_t) &FP_FSWGeneralProtocolServerInfo;
}

ESSATMAC_ErrCodes FSWGeneral_setInstrumentTimeResp(
                RespContext_t* ctx,
                const FSWGENERAL_eCommandExecutionReturn_t eExecutionSuccess
)
{
#ifndef BIG_ENDIAN_PLATFORM
    FSWGeneralsetInstrumentTimeProtocolResponseData_t responseParams;
#else  // #ifndef BIG_ENDIAN_PLATFORM
    uint8_t responseParams[sizeof(FSWGeneralsetInstrumentTimeProtocolResponseData_t)] = { 0 };
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    ESSATMAC_ErrCodes sendResult = ESSATMAC_EC_NULL;

    STATIC_ASSERT_SIZE_CHECK(FSWGeneralsetInstrumentTimeProtocolResponseData_t);

    if (ctx != NULL)
    {
#ifndef BIG_ENDIAN_PLATFORM
        // fill message header
        // RS485 wire protocol also uses LE byte order -> serialization of params is not needed
        responseParams.hdr.protoId = ES_SAT_FUNC_PROTOCOL_ID_FSWGENERAL;
        responseParams.hdr.funcId  = FSWGENERAL_SETINSTRUMENTTIME_FUNCRESP_ID;
        responseParams.hdr.seqId   = ctx->seqId;
        responseParams.hdr.errCode = ESSA_FP_ERRCODE_NOERROR;
        SET_RESPONSE(responseParams.hdr);

        // fill message data
        responseParams.data.eExecutionSuccess = eExecutionSuccess;
#else // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Serialize request fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

        sendResult = ESSA_Stack_SendFrameEx((ESSASNetInterface) ctx->nInterfaceNumber,
                                            ctx->netType,
                                            ctx->nAddr,
                                            ES_SAT_MAC_PROTOCOL_ID_FP_LAYER,
#ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) &responseParams,
#else // #ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) responseParams,
#endif // #ifndef BIG_ENDIAN_PLATFORM
                                            sizeof(FSWGeneralsetInstrumentTimeProtocolResponseData_t),
                                            STACK_SENDFRAME_DEFAULT_PRIO,
                                            (ESSATMAC_DrvResult_Cbk_t) NULL,
                                            (uint32_t *) NULL);
    }

    return sendResult;
}

ESSATMAC_ErrCodes FSWGeneral_setInstrumentDateResp(
                RespContext_t* ctx,
                const FSWGENERAL_eCommandExecutionReturn_t eExecutionSuccess
)
{
#ifndef BIG_ENDIAN_PLATFORM
    FSWGeneralsetInstrumentDateProtocolResponseData_t responseParams;
#else  // #ifndef BIG_ENDIAN_PLATFORM
    uint8_t responseParams[sizeof(FSWGeneralsetInstrumentDateProtocolResponseData_t)] = { 0 };
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    ESSATMAC_ErrCodes sendResult = ESSATMAC_EC_NULL;

    STATIC_ASSERT_SIZE_CHECK(FSWGeneralsetInstrumentDateProtocolResponseData_t);

    if (ctx != NULL)
    {
#ifndef BIG_ENDIAN_PLATFORM
        // fill message header
        // RS485 wire protocol also uses LE byte order -> serialization of params is not needed
        responseParams.hdr.protoId = ES_SAT_FUNC_PROTOCOL_ID_FSWGENERAL;
        responseParams.hdr.funcId  = FSWGENERAL_SETINSTRUMENTDATE_FUNCRESP_ID;
        responseParams.hdr.seqId   = ctx->seqId;
        responseParams.hdr.errCode = ESSA_FP_ERRCODE_NOERROR;
        SET_RESPONSE(responseParams.hdr);

        // fill message data
        responseParams.data.eExecutionSuccess = eExecutionSuccess;
#else // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Serialize request fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

        sendResult = ESSA_Stack_SendFrameEx((ESSASNetInterface) ctx->nInterfaceNumber,
                                            ctx->netType,
                                            ctx->nAddr,
                                            ES_SAT_MAC_PROTOCOL_ID_FP_LAYER,
#ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) &responseParams,
#else // #ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) responseParams,
#endif // #ifndef BIG_ENDIAN_PLATFORM
                                            sizeof(FSWGeneralsetInstrumentDateProtocolResponseData_t),
                                            STACK_SENDFRAME_DEFAULT_PRIO,
                                            (ESSATMAC_DrvResult_Cbk_t) NULL,
                                            (uint32_t *) NULL);
    }

    return sendResult;
}

ESSATMAC_ErrCodes FSWGeneral_getInstrumentTimeDateResp(
                RespContext_t* ctx,
                const FSWGENERAL_eMatch_t eMatch,
                const FSWGENERAL_stime_t * const sTimeSharp,
                const FSWGENERAL_sdate_t * const sDateSharp,
                const FSWGENERAL_stime_t * const sTimeMeddea,
                const FSWGENERAL_sdate_t * const sDateMeddea
)
{
#ifndef BIG_ENDIAN_PLATFORM
    FSWGeneralgetInstrumentTimeDateProtocolResponseData_t responseParams;
#else  // #ifndef BIG_ENDIAN_PLATFORM
    uint8_t responseParams[sizeof(FSWGeneralgetInstrumentTimeDateProtocolResponseData_t)] = { 0 };
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    ESSATMAC_ErrCodes sendResult = ESSATMAC_EC_NULL;

    STATIC_ASSERT_SIZE_CHECK(FSWGeneralgetInstrumentTimeDateProtocolResponseData_t);

    if ((ctx != NULL) && (sTimeSharp != NULL) && (sDateSharp != NULL) && (sTimeMeddea != NULL) && (sDateMeddea != NULL))
    {
#ifndef BIG_ENDIAN_PLATFORM
        // fill message header
        // RS485 wire protocol also uses LE byte order -> serialization of params is not needed
        responseParams.hdr.protoId = ES_SAT_FUNC_PROTOCOL_ID_FSWGENERAL;
        responseParams.hdr.funcId  = FSWGENERAL_GETINSTRUMENTTIMEDATE_FUNCRESP_ID;
        responseParams.hdr.seqId   = ctx->seqId;
        responseParams.hdr.errCode = ESSA_FP_ERRCODE_NOERROR;
        SET_RESPONSE(responseParams.hdr);

        // fill message data
        responseParams.data.eMatch = eMatch;
        if (sTimeSharp != NULL)
        {
            responseParams.data.sTimeSharp = *(sTimeSharp);
        }
        else
        {
            (void) memset((void *) &responseParams.data.sTimeSharp,
                          0U,
                          sizeof(responseParams.data.sTimeSharp));
        }
        if (sDateSharp != NULL)
        {
            responseParams.data.sDateSharp = *(sDateSharp);
        }
        else
        {
            (void) memset((void *) &responseParams.data.sDateSharp,
                          0U,
                          sizeof(responseParams.data.sDateSharp));
        }
        if (sTimeMeddea != NULL)
        {
            responseParams.data.sTimeMeddea = *(sTimeMeddea);
        }
        else
        {
            (void) memset((void *) &responseParams.data.sTimeMeddea,
                          0U,
                          sizeof(responseParams.data.sTimeMeddea));
        }
        if (sDateMeddea != NULL)
        {
            responseParams.data.sDateMeddea = *(sDateMeddea);
        }
        else
        {
            (void) memset((void *) &responseParams.data.sDateMeddea,
                          0U,
                          sizeof(responseParams.data.sDateMeddea));
        }
#else // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Serialize request fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

        sendResult = ESSA_Stack_SendFrameEx((ESSASNetInterface) ctx->nInterfaceNumber,
                                            ctx->netType,
                                            ctx->nAddr,
                                            ES_SAT_MAC_PROTOCOL_ID_FP_LAYER,
#ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) &responseParams,
#else // #ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) responseParams,
#endif // #ifndef BIG_ENDIAN_PLATFORM
                                            sizeof(FSWGeneralgetInstrumentTimeDateProtocolResponseData_t),
                                            STACK_SENDFRAME_DEFAULT_PRIO,
                                            (ESSATMAC_DrvResult_Cbk_t) NULL,
                                            (uint32_t *) NULL);
    }

    return sendResult;
}

ESSATMAC_ErrCodes FSWGeneral_getInstrumentModesResp(
                RespContext_t* ctx,
                const FSWGENERAL_eSHARPModes_t eModeSharp,
                const FSWGENERAL_eMEDDEAModes_t eModeMeddea
)
{
#ifndef BIG_ENDIAN_PLATFORM
    FSWGeneralgetInstrumentModesProtocolResponseData_t responseParams;
#else  // #ifndef BIG_ENDIAN_PLATFORM
    uint8_t responseParams[sizeof(FSWGeneralgetInstrumentModesProtocolResponseData_t)] = { 0 };
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    ESSATMAC_ErrCodes sendResult = ESSATMAC_EC_NULL;

    STATIC_ASSERT_SIZE_CHECK(FSWGeneralgetInstrumentModesProtocolResponseData_t);

    if (ctx != NULL)
    {
#ifndef BIG_ENDIAN_PLATFORM
        // fill message header
        // RS485 wire protocol also uses LE byte order -> serialization of params is not needed
        responseParams.hdr.protoId = ES_SAT_FUNC_PROTOCOL_ID_FSWGENERAL;
        responseParams.hdr.funcId  = FSWGENERAL_GETINSTRUMENTMODES_FUNCRESP_ID;
        responseParams.hdr.seqId   = ctx->seqId;
        responseParams.hdr.errCode = ESSA_FP_ERRCODE_NOERROR;
        SET_RESPONSE(responseParams.hdr);

        // fill message data
        responseParams.data.eModeSharp = eModeSharp;
        responseParams.data.eModeMeddea = eModeMeddea;
#else // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Serialize request fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

        sendResult = ESSA_Stack_SendFrameEx((ESSASNetInterface) ctx->nInterfaceNumber,
                                            ctx->netType,
                                            ctx->nAddr,
                                            ES_SAT_MAC_PROTOCOL_ID_FP_LAYER,
#ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) &responseParams,
#else // #ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) responseParams,
#endif // #ifndef BIG_ENDIAN_PLATFORM
                                            sizeof(FSWGeneralgetInstrumentModesProtocolResponseData_t),
                                            STACK_SENDFRAME_DEFAULT_PRIO,
                                            (ESSATMAC_DrvResult_Cbk_t) NULL,
                                            (uint32_t *) NULL);
    }

    return sendResult;
}

ESSATMAC_ErrCodes FSWGeneral_setInstrumentModesResp(
                RespContext_t* ctx,
                const FSWGENERAL_eCommandExecutionReturn_t eOpResult,
                const FSWGENERAL_eSHARPModes_t eModeSharp,
                const FSWGENERAL_eMEDDEAModes_t eModeMeddea
)
{
#ifndef BIG_ENDIAN_PLATFORM
    FSWGeneralsetInstrumentModesProtocolResponseData_t responseParams;
#else  // #ifndef BIG_ENDIAN_PLATFORM
    uint8_t responseParams[sizeof(FSWGeneralsetInstrumentModesProtocolResponseData_t)] = { 0 };
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    ESSATMAC_ErrCodes sendResult = ESSATMAC_EC_NULL;

    STATIC_ASSERT_SIZE_CHECK(FSWGeneralsetInstrumentModesProtocolResponseData_t);

    if (ctx != NULL)
    {
#ifndef BIG_ENDIAN_PLATFORM
        // fill message header
        // RS485 wire protocol also uses LE byte order -> serialization of params is not needed
        responseParams.hdr.protoId = ES_SAT_FUNC_PROTOCOL_ID_FSWGENERAL;
        responseParams.hdr.funcId  = FSWGENERAL_SETINSTRUMENTMODES_FUNCRESP_ID;
        responseParams.hdr.seqId   = ctx->seqId;
        responseParams.hdr.errCode = ESSA_FP_ERRCODE_NOERROR;
        SET_RESPONSE(responseParams.hdr);

        // fill message data
        responseParams.data.eOpResult = eOpResult;
        responseParams.data.eModeSharp = eModeSharp;
        responseParams.data.eModeMeddea = eModeMeddea;
#else // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Serialize request fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

        sendResult = ESSA_Stack_SendFrameEx((ESSASNetInterface) ctx->nInterfaceNumber,
                                            ctx->netType,
                                            ctx->nAddr,
                                            ES_SAT_MAC_PROTOCOL_ID_FP_LAYER,
#ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) &responseParams,
#else // #ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) responseParams,
#endif // #ifndef BIG_ENDIAN_PLATFORM
                                            sizeof(FSWGeneralsetInstrumentModesProtocolResponseData_t),
                                            STACK_SENDFRAME_DEFAULT_PRIO,
                                            (ESSATMAC_DrvResult_Cbk_t) NULL,
                                            (uint32_t *) NULL);
    }

    return sendResult;
}


