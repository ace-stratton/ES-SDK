/*!
********************************************************************************************
* @file FP_FSWGeneralProtocolTypes.h
* @brief Protocol public type declarations
********************************************************************************************
* @version           interface FSWGeneral v0.1
*
* @copyright         (C) Copyright EnduroSat
*
*                    Contents and presentations are protected world-wide.
*                    Any kind of using, copying etc. is prohibited without prior permission.
*                    All rights - incl. industrial property rights - are reserved.
*
*-------------------------------------------------------------------------------------------
* GENERATOR: org.endurosat.generators.macchiato.binders.Gen_C v2.12
*-------------------------------------------------------------------------------------------
* !!! Please note that this code is fully GENERATED and shall not be manually modified as
* all changes will be overwritten !!!
********************************************************************************************
*/

#ifndef __FP_FSWGENERALPROTOCOLTYPES_H__
#define __FP_FSWGENERALPROTOCOLTYPES_H__

#include <stddef.h>
#include "FP_common/FP_BaseProtocolTypes.h"
#include "FP_common/FP_Helpers.h"

/**********************************************************************
 *
 *  Shared defines
 *
 **********************************************************************/
#define ES_SAT_FUNC_PROTOCOL_ID_FSWGENERAL ((uint16_t) (0x00000068))

#define FSWGENERAL_SETINSTRUMENTTIME_FUNC_ID ((funcIdType_t) 0x00000001)
#define FSWGENERAL_SETINSTRUMENTDATE_FUNC_ID ((funcIdType_t) 0x00000002)
#define FSWGENERAL_GETINSTRUMENTTIMEDATE_FUNC_ID ((funcIdType_t) 0x00000003)
#define FSWGENERAL_GETINSTRUMENTMODES_FUNC_ID ((funcIdType_t) 0x00000004)
#define FSWGENERAL_SETINSTRUMENTMODES_FUNC_ID ((funcIdType_t) 0x00000005)
#define FSWGENERAL_SETINSTRUMENTTIME_FUNCRESP_ID ((funcIdType_t) 0x00000001)
#define FSWGENERAL_SETINSTRUMENTDATE_FUNCRESP_ID ((funcIdType_t) 0x00000002)
#define FSWGENERAL_GETINSTRUMENTTIMEDATE_FUNCRESP_ID ((funcIdType_t) 0x00000003)
#define FSWGENERAL_GETINSTRUMENTMODES_FUNCRESP_ID ((funcIdType_t) 0x00000004)
#define FSWGENERAL_SETINSTRUMENTMODES_FUNCRESP_ID ((funcIdType_t) 0x00000005)

/**********************************************************************
 *
 *  Type definitions
 *
 **********************************************************************/
/*
    Shows status of sent command
*/
#define FSWGENERAL_ECOMMANDEXECUTIONRETURN_SUCCESS ((uint8_t) 0)
#define FSWGENERAL_ECOMMANDEXECUTIONRETURN_FAIL ((uint8_t) 1)
#define FSWGENERAL_ECOMMANDEXECUTIONRETURN_MAX_CNT  ((uint8_t) 2)
typedef uint8_t FSWGENERAL_eCommandExecutionReturn_t;

/*
    Shows if two values match
*/
#define FSWGENERAL_EMATCH_MATCH ((uint8_t) 0)
#define FSWGENERAL_EMATCH_NO_MATCH ((uint8_t) 1)
#define FSWGENERAL_EMATCH_MAX_CNT  ((uint8_t) 2)
typedef uint8_t FSWGENERAL_eMatch_t;

/*
    General modes for both instruments with no paramters
*/
#define FSWGENERAL_EINSTRUMENTMODES_IDLE_Mode ((uint8_t) 0)
#define FSWGENERAL_EINSTRUMENTMODES_Engineering_Mode ((uint8_t) 1)
#define FSWGENERAL_EINSTRUMENTMODES_Nominal_Science_Mode ((uint8_t) 2)
#define FSWGENERAL_EINSTRUMENTMODES_Safe_Mode ((uint8_t) 3)
#define FSWGENERAL_EINSTRUMENTMODES_Inst_Off_Mode ((uint8_t) 4)
#define FSWGENERAL_EINSTRUMENTMODES_MAX_CNT  ((uint8_t) 5)
typedef uint8_t FSWGENERAL_eInstrumentModes_t;

/*
    Possible MEDDEA Modes
*/
#define FSWGENERAL_EMEDDEAMODES_MEDDEA_IDLE_MODE ((uint8_t) 0)
#define FSWGENERAL_EMEDDEAMODES_MEDDEA_Engineering_Mode ((uint8_t) 1)
#define FSWGENERAL_EMEDDEAMODES_MEDDEA_Nominal_Science_Mode ((uint8_t) 2)
#define FSWGENERAL_EMEDDEAMODES_MEDDEA_Reduced_Readout_Science_Mode ((uint8_t) 3)
#define FSWGENERAL_EMEDDEAMODES_MEDDEA_Depolarization_Mode ((uint8_t) 4)
#define FSWGENERAL_EMEDDEAMODES_MEDDEA_Ramp_Mode ((uint8_t) 5)
#define FSWGENERAL_EMEDDEAMODES_MEDDEA_Pulser_Calibration_Mode ((uint8_t) 6)
#define FSWGENERAL_EMEDDEAMODES_MEDDEA_Safe_Mode ((uint8_t) 7)
#define FSWGENERAL_EMEDDEAMODES_MEDDEA_Off_Mode ((uint8_t) 8)
#define FSWGENERAL_EMEDDEAMODES_MAX_CNT  ((uint8_t) 9)
typedef uint8_t FSWGENERAL_eMEDDEAModes_t;

/*
    Possible SHARP Modes
*/
#define FSWGENERAL_ESHARPMODES_SHARP_IDLE_MODE ((uint8_t) 0)
#define FSWGENERAL_ESHARPMODES_SHARP_Low_Power_Mode ((uint8_t) 1)
#define FSWGENERAL_ESHARPMODES_SHARP_Engineering_Mode ((uint8_t) 2)
#define FSWGENERAL_ESHARPMODES_SHARP_Nominal_Science_Mode ((uint8_t) 3)
#define FSWGENERAL_ESHARPMODES_SHARP_Fast_Readout_Science_Mode ((uint8_t) 4)
#define FSWGENERAL_ESHARPMODES_SHARP_Safe_Mode ((uint8_t) 5)
#define FSWGENERAL_ESHARPMODES_SHARP_State_Machine_Off ((uint8_t) 6)
#define FSWGENERAL_ESHARPMODES_SHARP_State_Machine_On ((uint8_t) 7)
#define FSWGENERAL_ESHARPMODES_MAX_CNT  ((uint8_t) 8)
typedef uint8_t FSWGENERAL_eSHARPModes_t;

/*
    Date
*/
typedef struct {
    uint16_t u16Year;
    uint8_t u8Mon;
    uint8_t u8Day;
} PACKED_STRUCT FSWGENERAL_sdate_t;

/*
    Time
*/
typedef struct {
    uint8_t u8Hour;
    uint8_t u8Min;
    uint8_t u8Sec;
    uint16_t u16Ms;
    uint16_t u16Us;
} PACKED_STRUCT FSWGENERAL_stime_t;


typedef struct {
    bool bGNSS;
    FSWGENERAL_stime_t sTime;
} PACKED_STRUCT FSWGeneralsetInstrumentTimeRequestData_t;

typedef struct {
    bool bGNSS;
    FSWGENERAL_sdate_t sDate;
} PACKED_STRUCT FSWGeneralsetInstrumentDateRequestData_t;

typedef struct {
    FSWGENERAL_eInstrumentModes_t eModeGeneral;
} PACKED_STRUCT FSWGeneralsetInstrumentModesRequestData_t;


typedef struct {
    FSWGENERAL_eCommandExecutionReturn_t eExecutionSuccess;
} PACKED_STRUCT FSWGeneralsetInstrumentTimeResponseData_t;

typedef struct {
    FSWGENERAL_eCommandExecutionReturn_t eExecutionSuccess;
} PACKED_STRUCT FSWGeneralsetInstrumentDateResponseData_t;

typedef struct {
    FSWGENERAL_eMatch_t eMatch;
    FSWGENERAL_stime_t sTimeSharp;
    FSWGENERAL_sdate_t sDateSharp;
    FSWGENERAL_stime_t sTimeMeddea;
    FSWGENERAL_sdate_t sDateMeddea;
} PACKED_STRUCT FSWGeneralgetInstrumentTimeDateResponseData_t;

typedef struct {
    FSWGENERAL_eSHARPModes_t eModeSharp;
    FSWGENERAL_eMEDDEAModes_t eModeMeddea;
} PACKED_STRUCT FSWGeneralgetInstrumentModesResponseData_t;

typedef struct {
    FSWGENERAL_eCommandExecutionReturn_t eOpResult;
    FSWGENERAL_eSHARPModes_t eModeSharp;
    FSWGENERAL_eMEDDEAModes_t eModeMeddea;
} PACKED_STRUCT FSWGeneralsetInstrumentModesResponseData_t;


#endif  // #ifndef __FP_FSWGENERALPROTOCOLTYPES_H__

