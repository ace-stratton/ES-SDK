/*!
********************************************************************************************
* @file FP_FSWGeneralProtocolServer.h
* @brief ESSA Stack server-side public API declaration
********************************************************************************************
* @version           interface FSWGeneral v0.1
*
* @copyright         (C) Copyright EnduroSat
*
*                    Contents and presentations are protected world-wide.
*                    Any kind of using, copying etc. is prohibited without prior permission.
*                    All rights - incl. industrial property rights - are reserved.
*
*-------------------------------------------------------------------------------------------
* GENERATOR: org.endurosat.generators.macchiato.binders.Gen_C v2.12
*-------------------------------------------------------------------------------------------
* !!! Please note that this code is fully GENERATED and shall not be manually modified as
* all changes will be overwritten !!!
********************************************************************************************
*/

#ifndef __FP_FSWGENERALPROTOCOLSERVER_H__
#define __FP_FSWGENERALPROTOCOLSERVER_H__

#include "FP_FSWGeneralProtocolTypes.h"

typedef void (*pfFSWGeneral_setInstrumentTimeRequestHandler_t)(ReqContext_t *ctx, FSWGeneralsetInstrumentTimeRequestData_t *pRequestData);
typedef void (*pfFSWGeneral_setInstrumentDateRequestHandler_t)(ReqContext_t *ctx, FSWGeneralsetInstrumentDateRequestData_t *pRequestData);
typedef void (*pfFSWGeneral_getInstrumentTimeDateRequestHandler_t)(ReqContext_t *ctx);
typedef void (*pfFSWGeneral_getInstrumentModesRequestHandler_t)(ReqContext_t *ctx);
typedef void (*pfFSWGeneral_setInstrumentModesRequestHandler_t)(ReqContext_t *ctx, FSWGeneralsetInstrumentModesRequestData_t *pRequestData);

typedef struct {
    pfFSWGeneral_setInstrumentTimeRequestHandler_t FSWGeneral_setInstrumentTimeRequestHandler;
    pfFSWGeneral_setInstrumentDateRequestHandler_t FSWGeneral_setInstrumentDateRequestHandler;
    pfFSWGeneral_getInstrumentTimeDateRequestHandler_t FSWGeneral_getInstrumentTimeDateRequestHandler;
    pfFSWGeneral_getInstrumentModesRequestHandler_t FSWGeneral_getInstrumentModesRequestHandler;
    pfFSWGeneral_setInstrumentModesRequestHandler_t FSWGeneral_setInstrumentModesRequestHandler;
} FSWGeneral_ServerApi_t;

/**********************************************************************
 *
 *  Server protocol ESSA descriptor
 *
 **********************************************************************/
extern const ESSA_Stack_FunctionProtocolInfo_t FP_FSWGeneralProtocolServerInfo;

/**********************************************************************
 *
 *  Public methods
 *
 **********************************************************************/
void FSWGeneral_registerServerApi(FSWGeneral_ServerApi_t *pSrvApiHandlers);

// @deprecated - will be removed in the future - use FP_FSWGeneralProtocolServerInfo directly
ESSA_pStack_FunctionProtocolInfo_t FSWGeneral_getServerProtocolDescriptor(void);

ESSATMAC_ErrCodes FSWGeneral_setInstrumentTimeResp(
                RespContext_t* ctx,
                const FSWGENERAL_eCommandExecutionReturn_t eExecutionSuccess
);

ESSATMAC_ErrCodes FSWGeneral_setInstrumentDateResp(
                RespContext_t* ctx,
                const FSWGENERAL_eCommandExecutionReturn_t eExecutionSuccess
);

ESSATMAC_ErrCodes FSWGeneral_getInstrumentTimeDateResp(
                RespContext_t* ctx,
                const FSWGENERAL_eMatch_t eMatch,
                const FSWGENERAL_stime_t * const sTimeSharp,
                const FSWGENERAL_sdate_t * const sDateSharp,
                const FSWGENERAL_stime_t * const sTimeMeddea,
                const FSWGENERAL_sdate_t * const sDateMeddea
);

ESSATMAC_ErrCodes FSWGeneral_getInstrumentModesResp(
                RespContext_t* ctx,
                const FSWGENERAL_eSHARPModes_t eModeSharp,
                const FSWGENERAL_eMEDDEAModes_t eModeMeddea
);

ESSATMAC_ErrCodes FSWGeneral_setInstrumentModesResp(
                RespContext_t* ctx,
                const FSWGENERAL_eCommandExecutionReturn_t eOpResult,
                const FSWGENERAL_eSHARPModes_t eModeSharp,
                const FSWGENERAL_eMEDDEAModes_t eModeMeddea
);


#endif  // #ifndef __FP_FSWGENERALPROTOCOLSERVER_H__
