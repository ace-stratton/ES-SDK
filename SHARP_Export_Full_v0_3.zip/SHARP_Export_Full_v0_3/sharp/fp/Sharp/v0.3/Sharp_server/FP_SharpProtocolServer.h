/*!
********************************************************************************************
* @file FP_SharpProtocolServer.h
* @brief ESSA Stack server-side public API declaration
********************************************************************************************
* @version           interface Sharp v0.3
*
* @copyright         (C) Copyright EnduroSat
*
*                    Contents and presentations are protected world-wide.
*                    Any kind of using, copying etc. is prohibited without prior permission.
*                    All rights - incl. industrial property rights - are reserved.
*
*-------------------------------------------------------------------------------------------
* GENERATOR: org.endurosat.generators.macchiato.binders.Gen_C v2.12
*-------------------------------------------------------------------------------------------
* !!! Please note that this code is fully GENERATED and shall not be manually modified as
* all changes will be overwritten !!!
********************************************************************************************
*/

#ifndef __FP_SHARPPROTOCOLSERVER_H__
#define __FP_SHARPPROTOCOLSERVER_H__

#include "FP_SharpProtocolTypes.h"

typedef void (*pfSharp_getHealthInfoRequestHandler_t)(ReqContext_t *ctx);
typedef void (*pfSharp_getSHIPInfoRequestHandler_t)(ReqContext_t *ctx);
typedef void (*pfSharp_setDetectorPowerRequestHandler_t)(ReqContext_t *ctx, SharpsetDetectorPowerRequestData_t *pRequestData);
typedef void (*pfSharp_setSharpTimeRequestHandler_t)(ReqContext_t *ctx, SharpsetSharpTimeRequestData_t *pRequestData);
typedef void (*pfSharp_setSharpDateRequestHandler_t)(ReqContext_t *ctx, SharpsetSharpDateRequestData_t *pRequestData);
typedef void (*pfSharp_getSharpTimeDateRequestHandler_t)(ReqContext_t *ctx);
typedef void (*pfSharp_getSharpModeRequestHandler_t)(ReqContext_t *ctx);
typedef void (*pfSharp_setSharpModeRequestHandler_t)(ReqContext_t *ctx, SharpsetSharpModeRequestData_t *pRequestData);

typedef struct {
    pfSharp_getHealthInfoRequestHandler_t Sharp_getHealthInfoRequestHandler;
    pfSharp_getSHIPInfoRequestHandler_t Sharp_getSHIPInfoRequestHandler;
    pfSharp_setDetectorPowerRequestHandler_t Sharp_setDetectorPowerRequestHandler;
    pfSharp_setSharpTimeRequestHandler_t Sharp_setSharpTimeRequestHandler;
    pfSharp_setSharpDateRequestHandler_t Sharp_setSharpDateRequestHandler;
    pfSharp_getSharpTimeDateRequestHandler_t Sharp_getSharpTimeDateRequestHandler;
    pfSharp_getSharpModeRequestHandler_t Sharp_getSharpModeRequestHandler;
    pfSharp_setSharpModeRequestHandler_t Sharp_setSharpModeRequestHandler;
} Sharp_ServerApi_t;

/**********************************************************************
 *
 *  Server protocol ESSA descriptor
 *
 **********************************************************************/
extern const ESSA_Stack_FunctionProtocolInfo_t FP_SharpProtocolServerInfo;

/**********************************************************************
 *
 *  Public methods
 *
 **********************************************************************/
void Sharp_registerServerApi(Sharp_ServerApi_t *pSrvApiHandlers);

// @deprecated - will be removed in the future - use FP_SharpProtocolServerInfo directly
ESSA_pStack_FunctionProtocolInfo_t Sharp_getServerProtocolDescriptor(void);

ESSATMAC_ErrCodes Sharp_getHealthInfoResp(
                RespContext_t* ctx,
                const SHARP_sdate_t * const sDate,
                const SHARP_stime_t * const sTime,
                const SHARP_sfaultstateSharp_t * const sFaults,
                const SHARP_sDetectorTemps_t * const sTemperatures,
                const SHARP_sDetectorVoltages_t * const sVoltages,
                const SHARP_sDetectorStatus_t * const sDetectorStatus
);

ESSATMAC_ErrCodes Sharp_getSHIPInfoResp(
                RespContext_t* ctx,
                const SHARP_sSHIPVersion_t * const sVersioning,
                const SHARP_sFPGAVersion_t * const sFpga_versioning,
                const SHARP_sSHIPStorage_t * const sShipStorage,
                const SHARP_sSHIPPower_t * const sShipPower
);

ESSATMAC_ErrCodes Sharp_setDetectorPowerResp(
                RespContext_t* ctx,
                const SHARP_DetectorPower_t eOpResult,
                const SHARP_sDetectorStatus_t * const sDetectorStatus
);

ESSATMAC_ErrCodes Sharp_setSharpTimeResp(
                RespContext_t* ctx,
                const SHARP_eCommandExecutionReturn_t eExecutionSuccess
);

ESSATMAC_ErrCodes Sharp_setSharpDateResp(
                RespContext_t* ctx,
                const SHARP_eCommandExecutionReturn_t eExecutionSuccess
);

ESSATMAC_ErrCodes Sharp_getSharpTimeDateResp(
                RespContext_t* ctx,
                const SHARP_stime_t * const sTime,
                const SHARP_sdate_t * const sDate
);

ESSATMAC_ErrCodes Sharp_getSharpModeResp(
                RespContext_t* ctx,
                const SHARP_sSHARPParameters_t * const sParameters,
                const SHARP_eSHARPModes_t eMode
);

ESSATMAC_ErrCodes Sharp_setSharpModeResp(
                RespContext_t* ctx,
                const SHARP_eCommandExecutionReturn_t eOpResult,
                const SHARP_sSHARPParameters_t * const sParameters,
                const SHARP_eSHARPModes_t eMode
);


#endif  // #ifndef __FP_SHARPPROTOCOLSERVER_H__
