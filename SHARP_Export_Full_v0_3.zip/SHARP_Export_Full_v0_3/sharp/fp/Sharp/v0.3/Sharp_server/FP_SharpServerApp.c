/*!
********************************************************************************************
* @file FP_SharpServerApp.c
* @brief ServerApp implementation template generator
********************************************************************************************
* @version           interface Sharp v0.3
*
* @copyright         (C) Copyright EnduroSat
*
*                    Contents and presentations are protected world-wide.
*                    Any kind of using, copying etc. is prohibited without prior permission.
*                    All rights - incl. industrial property rights - are reserved.
*
*-------------------------------------------------------------------------------------------
* GENERATOR: org.endurosat.generators.macchiato.binders.Gen_C v2.12
*-------------------------------------------------------------------------------------------
* !!! Please note that this code is fully GENERATED and shall not be manually modified as
* all changes will be overwritten !!!
********************************************************************************************
*/

#include "FP_SharpProtocolServer.h"

// @START_USER@ USER_INCLUDES
// Place user includes here to preserve them during merge!!!
// @END_USER@ USER_INCLUDES

/**********************************************************************
 *
 *  Local methods declarations
 *
 **********************************************************************/
// @START_USER@ USER_LOCAL_FUNC_DECL
// Place static function declarations here to preserve them during merge!!!
// @END_USER@ USER_LOCAL_FUNC_DECL
static void Sharp_getHealthInfoRequestHandlerImpl(ReqContext_t* pReqCtx);

static void Sharp_getSHIPInfoRequestHandlerImpl(ReqContext_t* pReqCtx);

static void Sharp_setDetectorPowerRequestHandlerImpl(ReqContext_t* pReqCtx,
            const SharpsetDetectorPowerRequestData_t* pRequestData);

static void Sharp_setSharpTimeRequestHandlerImpl(ReqContext_t* pReqCtx,
            const SharpsetSharpTimeRequestData_t* pRequestData);

static void Sharp_setSharpDateRequestHandlerImpl(ReqContext_t* pReqCtx,
            const SharpsetSharpDateRequestData_t* pRequestData);

static void Sharp_getSharpTimeDateRequestHandlerImpl(ReqContext_t* pReqCtx);

static void Sharp_getSharpModeRequestHandlerImpl(ReqContext_t* pReqCtx);

static void Sharp_setSharpModeRequestHandlerImpl(ReqContext_t* pReqCtx,
            const SharpsetSharpModeRequestData_t* pRequestData);


/**********************************************************************
 *
 *  Local variables
 *
 **********************************************************************/
// @START_USER@ USER_LOCAL_VARS_DECL
// Place static variable declarations here to preserve them during merge!!!
// @END_USER@ USER_LOCAL_VARS_DECL

static Sharp_ServerApi_t SharpServerApiCtx =
{
  .Sharp_getHealthInfoRequestHandler = (pfSharp_getHealthInfoRequestHandler_t) Sharp_getHealthInfoRequestHandlerImpl,
  .Sharp_getSHIPInfoRequestHandler = (pfSharp_getSHIPInfoRequestHandler_t) Sharp_getSHIPInfoRequestHandlerImpl,
  .Sharp_setDetectorPowerRequestHandler = (pfSharp_setDetectorPowerRequestHandler_t) Sharp_setDetectorPowerRequestHandlerImpl,
  .Sharp_setSharpTimeRequestHandler = (pfSharp_setSharpTimeRequestHandler_t) Sharp_setSharpTimeRequestHandlerImpl,
  .Sharp_setSharpDateRequestHandler = (pfSharp_setSharpDateRequestHandler_t) Sharp_setSharpDateRequestHandlerImpl,
  .Sharp_getSharpTimeDateRequestHandler = (pfSharp_getSharpTimeDateRequestHandler_t) Sharp_getSharpTimeDateRequestHandlerImpl,
  .Sharp_getSharpModeRequestHandler = (pfSharp_getSharpModeRequestHandler_t) Sharp_getSharpModeRequestHandlerImpl,
  .Sharp_setSharpModeRequestHandler = (pfSharp_setSharpModeRequestHandler_t) Sharp_setSharpModeRequestHandlerImpl
};

/**********************************************************************
 *
 *  Local methods implementation
 *
 **********************************************************************/
// @START_USER@ USER_LOCAL_FUNC_IMPL
// Place static functions implementation here to preserve it during merge!!!
// @END_USER@ USER_LOCAL_FUNC_IMPL

// @START@ Request handler for method Sharp::getHealthInfo (ID = 0x00000001)
static void Sharp_getHealthInfoRequestHandlerImpl(ReqContext_t* pReqCtx)
{
    ESSATMAC_ErrCodes respResult;
    RespContext_t respCtx;
    SHARP_sdate_t sDate;
    SHARP_stime_t sTime;
    SHARP_sfaultstateSharp_t sFaults;
    SHARP_sDetectorTemps_t sTemperatures;
    SHARP_sDetectorVoltages_t sVoltages;
    SHARP_sDetectorStatus_t sDetectorStatus;

    // @USER_VAR_SECTION_START@Sharp::getHealthInfo@
    // Put your local variables in this section to preserve during merge!
    // @USER_VAR_SECTION_END@Sharp::getHealthInfo@

    if (pReqCtx != NULL)
    {
        respCtx.nInterfaceNumber = pReqCtx->nInterfaceNumber;
        respCtx.netType = pReqCtx->netType;
        respCtx.nAddr = pReqCtx->nAddr;
        respCtx.seqId = pReqCtx->seqId;

        // @USER_CODE_SECTION_START@Sharp::getHealthInfo@
        
        // TODO: Put your implementation to handle the
        // received server response here!
        
        // @USER_CODE_SECTION_END@Sharp::getHealthInfo@

        respResult = Sharp_getHealthInfoResp(
                        &respCtx,
                        &sDate,
                        &sTime,
                        &sFaults,
                        &sTemperatures,
                        &sVoltages,
                        &sDetectorStatus
                     );

        if (respResult != ESSATMAC_EC_OK)
            TRACE_ERROR(ES_SAT_FUNC_PROTOCOL_ID_SHARP, SHARP_GETHEALTHINFO_FUNCRESP_ID, respResult);
    }
}
// @END@ Request handler for method Sharp::getHealthInfo (ID = 0x00000001)

// @START@ Request handler for method Sharp::getSHIPInfo (ID = 0x00000002)
static void Sharp_getSHIPInfoRequestHandlerImpl(ReqContext_t* pReqCtx)
{
    ESSATMAC_ErrCodes respResult;
    RespContext_t respCtx;
    SHARP_sSHIPVersion_t sVersioning;
    SHARP_sFPGAVersion_t sFpga_versioning;
    SHARP_sSHIPStorage_t sShipStorage;
    SHARP_sSHIPPower_t sShipPower;

    // @USER_VAR_SECTION_START@Sharp::getSHIPInfo@
    // Put your local variables in this section to preserve during merge!
    // @USER_VAR_SECTION_END@Sharp::getSHIPInfo@

    if (pReqCtx != NULL)
    {
        respCtx.nInterfaceNumber = pReqCtx->nInterfaceNumber;
        respCtx.netType = pReqCtx->netType;
        respCtx.nAddr = pReqCtx->nAddr;
        respCtx.seqId = pReqCtx->seqId;

        // @USER_CODE_SECTION_START@Sharp::getSHIPInfo@
        
        // TODO: Put your implementation to handle the
        // received server response here!
        
        // @USER_CODE_SECTION_END@Sharp::getSHIPInfo@

        respResult = Sharp_getSHIPInfoResp(
                        &respCtx,
                        &sVersioning,
                        &sFpga_versioning,
                        &sShipStorage,
                        &sShipPower
                     );

        if (respResult != ESSATMAC_EC_OK)
            TRACE_ERROR(ES_SAT_FUNC_PROTOCOL_ID_SHARP, SHARP_GETSHIPINFO_FUNCRESP_ID, respResult);
    }
}
// @END@ Request handler for method Sharp::getSHIPInfo (ID = 0x00000002)

// @START@ Request handler for method Sharp::setDetectorPower (ID = 0x00000003)
static void Sharp_setDetectorPowerRequestHandlerImpl(ReqContext_t *pReqCtx,
            const SharpsetDetectorPowerRequestData_t* pRequestData)
{
    ESSATMAC_ErrCodes respResult;
    RespContext_t respCtx;
    SHARP_DetectorPower_t eOpResult;
    SHARP_sDetectorStatus_t sDetectorStatus;

    // @USER_VAR_SECTION_START@Sharp::setDetectorPower@
    // Put your local variables in this section to preserve during merge!
    // @USER_VAR_SECTION_END@Sharp::setDetectorPower@

    if ((pReqCtx != NULL) && (pRequestData != NULL))
    {
        respCtx.nInterfaceNumber = pReqCtx->nInterfaceNumber;
        respCtx.netType = pReqCtx->netType;
        respCtx.nAddr = pReqCtx->nAddr;
        respCtx.seqId = pReqCtx->seqId;

        // @USER_CODE_SECTION_START@Sharp::setDetectorPower@
        
        // TODO: Put your implementation to handle the
        // received server response here!
        
        // @USER_CODE_SECTION_END@Sharp::setDetectorPower@

        respResult = Sharp_setDetectorPowerResp(
                        &respCtx,
                        eOpResult,
                        &sDetectorStatus
                     );

        if (respResult != ESSATMAC_EC_OK)
            TRACE_ERROR(ES_SAT_FUNC_PROTOCOL_ID_SHARP, SHARP_SETDETECTORPOWER_FUNCRESP_ID, respResult);
    }
}
// @END@ Request handler for method Sharp::setDetectorPower (ID = 0x00000003)

// @START@ Request handler for method Sharp::setSharpTime (ID = 0x00000004)
static void Sharp_setSharpTimeRequestHandlerImpl(ReqContext_t *pReqCtx,
            const SharpsetSharpTimeRequestData_t* pRequestData)
{
    ESSATMAC_ErrCodes respResult;
    RespContext_t respCtx;
    SHARP_eCommandExecutionReturn_t eExecutionSuccess;

    // @USER_VAR_SECTION_START@Sharp::setSharpTime@
    // Put your local variables in this section to preserve during merge!
    // @USER_VAR_SECTION_END@Sharp::setSharpTime@

    if ((pReqCtx != NULL) && (pRequestData != NULL))
    {
        respCtx.nInterfaceNumber = pReqCtx->nInterfaceNumber;
        respCtx.netType = pReqCtx->netType;
        respCtx.nAddr = pReqCtx->nAddr;
        respCtx.seqId = pReqCtx->seqId;

        // @USER_CODE_SECTION_START@Sharp::setSharpTime@
        
        // TODO: Put your implementation to handle the
        // received server response here!
        
        // @USER_CODE_SECTION_END@Sharp::setSharpTime@

        respResult = Sharp_setSharpTimeResp(
                        &respCtx,
                        eExecutionSuccess
                     );

        if (respResult != ESSATMAC_EC_OK)
            TRACE_ERROR(ES_SAT_FUNC_PROTOCOL_ID_SHARP, SHARP_SETSHARPTIME_FUNCRESP_ID, respResult);
    }
}
// @END@ Request handler for method Sharp::setSharpTime (ID = 0x00000004)

// @START@ Request handler for method Sharp::setSharpDate (ID = 0x00000005)
static void Sharp_setSharpDateRequestHandlerImpl(ReqContext_t *pReqCtx,
            const SharpsetSharpDateRequestData_t* pRequestData)
{
    ESSATMAC_ErrCodes respResult;
    RespContext_t respCtx;
    SHARP_eCommandExecutionReturn_t eExecutionSuccess;

    // @USER_VAR_SECTION_START@Sharp::setSharpDate@
    // Put your local variables in this section to preserve during merge!
    // @USER_VAR_SECTION_END@Sharp::setSharpDate@

    if ((pReqCtx != NULL) && (pRequestData != NULL))
    {
        respCtx.nInterfaceNumber = pReqCtx->nInterfaceNumber;
        respCtx.netType = pReqCtx->netType;
        respCtx.nAddr = pReqCtx->nAddr;
        respCtx.seqId = pReqCtx->seqId;

        // @USER_CODE_SECTION_START@Sharp::setSharpDate@
        
        // TODO: Put your implementation to handle the
        // received server response here!
        
        // @USER_CODE_SECTION_END@Sharp::setSharpDate@

        respResult = Sharp_setSharpDateResp(
                        &respCtx,
                        eExecutionSuccess
                     );

        if (respResult != ESSATMAC_EC_OK)
            TRACE_ERROR(ES_SAT_FUNC_PROTOCOL_ID_SHARP, SHARP_SETSHARPDATE_FUNCRESP_ID, respResult);
    }
}
// @END@ Request handler for method Sharp::setSharpDate (ID = 0x00000005)

// @START@ Request handler for method Sharp::getSharpTimeDate (ID = 0x00000006)
static void Sharp_getSharpTimeDateRequestHandlerImpl(ReqContext_t* pReqCtx)
{
    ESSATMAC_ErrCodes respResult;
    RespContext_t respCtx;
    SHARP_stime_t sTime;
    SHARP_sdate_t sDate;

    // @USER_VAR_SECTION_START@Sharp::getSharpTimeDate@
    // Put your local variables in this section to preserve during merge!
    // @USER_VAR_SECTION_END@Sharp::getSharpTimeDate@

    if (pReqCtx != NULL)
    {
        respCtx.nInterfaceNumber = pReqCtx->nInterfaceNumber;
        respCtx.netType = pReqCtx->netType;
        respCtx.nAddr = pReqCtx->nAddr;
        respCtx.seqId = pReqCtx->seqId;

        // @USER_CODE_SECTION_START@Sharp::getSharpTimeDate@
        
        // TODO: Put your implementation to handle the
        // received server response here!
        
        // @USER_CODE_SECTION_END@Sharp::getSharpTimeDate@

        respResult = Sharp_getSharpTimeDateResp(
                        &respCtx,
                        &sTime,
                        &sDate
                     );

        if (respResult != ESSATMAC_EC_OK)
            TRACE_ERROR(ES_SAT_FUNC_PROTOCOL_ID_SHARP, SHARP_GETSHARPTIMEDATE_FUNCRESP_ID, respResult);
    }
}
// @END@ Request handler for method Sharp::getSharpTimeDate (ID = 0x00000006)

// @START@ Request handler for method Sharp::getSharpMode (ID = 0x00000007)
static void Sharp_getSharpModeRequestHandlerImpl(ReqContext_t* pReqCtx)
{
    ESSATMAC_ErrCodes respResult;
    RespContext_t respCtx;
    SHARP_sSHARPParameters_t sParameters;
    SHARP_eSHARPModes_t eMode;

    // @USER_VAR_SECTION_START@Sharp::getSharpMode@
    // Put your local variables in this section to preserve during merge!
    // @USER_VAR_SECTION_END@Sharp::getSharpMode@

    if (pReqCtx != NULL)
    {
        respCtx.nInterfaceNumber = pReqCtx->nInterfaceNumber;
        respCtx.netType = pReqCtx->netType;
        respCtx.nAddr = pReqCtx->nAddr;
        respCtx.seqId = pReqCtx->seqId;

        // @USER_CODE_SECTION_START@Sharp::getSharpMode@
        
        // TODO: Put your implementation to handle the
        // received server response here!
        
        // @USER_CODE_SECTION_END@Sharp::getSharpMode@

        respResult = Sharp_getSharpModeResp(
                        &respCtx,
                        &sParameters,
                        eMode
                     );

        if (respResult != ESSATMAC_EC_OK)
            TRACE_ERROR(ES_SAT_FUNC_PROTOCOL_ID_SHARP, SHARP_GETSHARPMODE_FUNCRESP_ID, respResult);
    }
}
// @END@ Request handler for method Sharp::getSharpMode (ID = 0x00000007)

// @START@ Request handler for method Sharp::setSharpMode (ID = 0x00000008)
static void Sharp_setSharpModeRequestHandlerImpl(ReqContext_t *pReqCtx,
            const SharpsetSharpModeRequestData_t* pRequestData)
{
    ESSATMAC_ErrCodes respResult;
    RespContext_t respCtx;
    SHARP_eCommandExecutionReturn_t eOpResult;
    SHARP_sSHARPParameters_t sParameters;
    SHARP_eSHARPModes_t eMode;

    // @USER_VAR_SECTION_START@Sharp::setSharpMode@
    // Put your local variables in this section to preserve during merge!
    // @USER_VAR_SECTION_END@Sharp::setSharpMode@

    if ((pReqCtx != NULL) && (pRequestData != NULL))
    {
        respCtx.nInterfaceNumber = pReqCtx->nInterfaceNumber;
        respCtx.netType = pReqCtx->netType;
        respCtx.nAddr = pReqCtx->nAddr;
        respCtx.seqId = pReqCtx->seqId;

        // @USER_CODE_SECTION_START@Sharp::setSharpMode@
        
        // TODO: Put your implementation to handle the
        // received server response here!
        
        // @USER_CODE_SECTION_END@Sharp::setSharpMode@

        respResult = Sharp_setSharpModeResp(
                        &respCtx,
                        eOpResult,
                        &sParameters,
                        eMode
                     );

        if (respResult != ESSATMAC_EC_OK)
            TRACE_ERROR(ES_SAT_FUNC_PROTOCOL_ID_SHARP, SHARP_SETSHARPMODE_FUNCRESP_ID, respResult);
    }
}
// @END@ Request handler for method Sharp::setSharpMode (ID = 0x00000008)


/**********************************************************************
 *
 *  Public functions
 *
 **********************************************************************/
void SharpServerAppInit(void)
{
    Sharp_registerServerApi(&SharpServerApiCtx);
}
