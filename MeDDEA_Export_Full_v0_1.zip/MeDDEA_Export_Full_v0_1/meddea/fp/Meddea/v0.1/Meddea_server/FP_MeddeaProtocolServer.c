/*!
********************************************************************************************
* @file FP_MeddeaProtocolServer.c
* @brief ESSA Stack server-side implementation
********************************************************************************************
* @version           interface Meddea v0.1
*
* @copyright         (C) Copyright EnduroSat
*
*                    Contents and presentations are protected world-wide.
*                    Any kind of using, copying etc. is prohibited without prior permission.
*                    All rights - incl. industrial property rights - are reserved.
*
*-------------------------------------------------------------------------------------------
* GENERATOR: org.endurosat.generators.macchiato.binders.Gen_C v2.12
*-------------------------------------------------------------------------------------------
* !!! Please note that this code is fully GENERATED and shall not be manually modified as
* all changes will be overwritten !!!
********************************************************************************************
*/

#include "FP_MeddeaProtocolServer.h"
#include "FP_common/FP_ProtocolServerCommon.h"

#define Meddea_PROTOCOL_VERSION_MAJOR   ((uint8_t) 0)
#define Meddea_PROTOCOL_VERSION_MINOR   ((uint8_t) 1)

/**********************************************************************
 *
 *  Local type definitions
 *
 **********************************************************************/
typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
} PACKED_STRUCT MeddeagetMEDDEAModeProtocolRequestData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    MeddeagetMEDDEAModeResponseData_t data;
} PACKED_STRUCT MeddeagetMEDDEAModeProtocolResponseData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    MeddeasetMEDDEAModeRequestData_t data;
} PACKED_STRUCT MeddeasetMEDDEAModeProtocolRequestData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    MeddeasetMEDDEAModeResponseData_t data;
} PACKED_STRUCT MeddeasetMEDDEAModeProtocolResponseData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    MeddeasetMEDDEATimeRequestData_t data;
} PACKED_STRUCT MeddeasetMEDDEATimeProtocolRequestData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    MeddeasetMEDDEATimeResponseData_t data;
} PACKED_STRUCT MeddeasetMEDDEATimeProtocolResponseData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    MeddeasetMEDDEADateRequestData_t data;
} PACKED_STRUCT MeddeasetMEDDEADateProtocolRequestData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    MeddeasetMEDDEADateResponseData_t data;
} PACKED_STRUCT MeddeasetMEDDEADateProtocolResponseData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
} PACKED_STRUCT MeddeagetMEDDEATimeDateProtocolRequestData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    MeddeagetMEDDEATimeDateResponseData_t data;
} PACKED_STRUCT MeddeagetMEDDEATimeDateProtocolResponseData_t;


/**********************************************************************
 *
 *  Static methods declarations
 *
 **********************************************************************/
static bool fs_HandleData(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo);
static void fs_getMEDDEAModeReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo);
static void fs_setMEDDEAModeReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo);
static void fs_setMEDDEATimeReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo);
static void fs_setMEDDEADateReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo);
static void fs_getMEDDEATimeDateReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo);

/**********************************************************************
 *
 *  Public variable definitions
 *
 **********************************************************************/
const ESSA_Stack_FunctionProtocolInfo_t FP_MeddeaProtocolServerInfo = {
    .u16ProtocolId    = ES_SAT_FUNC_PROTOCOL_ID_MEDDEA,
    .pfDataHandlerCbk = fs_HandleData
};

/**********************************************************************
 *
 *  Static variable definitions
 *
 **********************************************************************/
static Meddea_ServerApi_t *pSrvApiHnd = NULL;

static const ProtocolFuncArrayEntry_t fs_aFuncArray[] = {
    { MEDDEA_GETMEDDEAMODE_FUNC_ID, fs_getMEDDEAModeReq },
    { MEDDEA_SETMEDDEAMODE_FUNC_ID, fs_setMEDDEAModeReq },
    { MEDDEA_SETMEDDEATIME_FUNC_ID, fs_setMEDDEATimeReq },
    { MEDDEA_SETMEDDEADATE_FUNC_ID, fs_setMEDDEADateReq },
    { MEDDEA_GETMEDDEATIMEDATE_FUNC_ID, fs_getMEDDEATimeDateReq }
};

/**********************************************************************
 *
 *  Static methods implementation
 *
 **********************************************************************/
static bool fs_HandleData(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo)
{
    ESSA_Stack_FP_MsgHdr_t *pHdr = NULL;
    bool bIsFuncSupported = false;
    uint8_t i;

    // Basic header validity check
    if ((fp_DataInfo == NULL) ||
        (fp_DataInfo->u16DataSize < sizeof(ESSA_Stack_FP_MsgHdr_t)) ||
        (fp_DataInfo->pu8Data == NULL))
    {
        return false;
    }

    pHdr = (ESSA_Stack_FP_MsgHdr_t *) fp_DataInfo->pu8Data;

    if (IS_REQUEST(*pHdr))
    {
        for (i = 0; i < COUNT_OF(fs_aFuncArray); i++)
        {
            if (fs_aFuncArray[i].funcId == pHdr->funcId)
            {
                if (fs_aFuncArray[i].pfFunc != NULL)
                {
                    bIsFuncSupported = true;
                    fs_aFuncArray[i].pfFunc(fp_DataInfo);
                }

                break;
            }
        }

        if (!bIsFuncSupported)
            (void) ProtocolSendErrorResp(fp_DataInfo, (uint8_t) ESSA_FP_ERRCODE_FUNC_NOT_SUPPORTED);
    }

    return bIsFuncSupported;
}

static void fs_getMEDDEAModeReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo)
{
    MeddeagetMEDDEAModeProtocolRequestData_t *fullrequest = (MeddeagetMEDDEAModeProtocolRequestData_t *) fp_DataInfo->pu8Data;
    ReqContext_t requestCtx;

    STATIC_ASSERT_SIZE_CHECK(MeddeagetMEDDEAModeProtocolRequestData_t);

    if ((fullrequest == NULL) || (pSrvApiHnd == NULL) || (fp_DataInfo->u16DataSize != sizeof(*fullrequest)))
    {
        return;
    }
#ifndef BIG_ENDIAN_PLATFORM
    // no out-arguments specified for response - simple acknowledge call
#else   // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Deserialize response fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    if (pSrvApiHnd->Meddea_getMEDDEAModeRequestHandler != NULL)
    {
        requestCtx.nInterfaceNumber = fp_DataInfo->pMACContext->nInterfaceNumber;
        requestCtx.netType = fp_DataInfo->pMACContext->netType;
        requestCtx.nAddr = fp_DataInfo->pMACContext->nSourceAddr;
        requestCtx.seqId = fullrequest->hdr.seqId;

        pSrvApiHnd->Meddea_getMEDDEAModeRequestHandler(&requestCtx);
    }
}

static void fs_setMEDDEAModeReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo)
{
    MeddeasetMEDDEAModeProtocolRequestData_t *fullrequest = (MeddeasetMEDDEAModeProtocolRequestData_t *) fp_DataInfo->pu8Data;
    MeddeasetMEDDEAModeRequestData_t *requestPayload = NULL;
    ReqContext_t requestCtx;

    STATIC_ASSERT_SIZE_CHECK(MeddeasetMEDDEAModeProtocolRequestData_t);

    if ((fullrequest == NULL) || (pSrvApiHnd == NULL) || (fp_DataInfo->u16DataSize != sizeof(*fullrequest)))
    {
        return;
    }
#ifndef BIG_ENDIAN_PLATFORM
    requestPayload = (MeddeasetMEDDEAModeRequestData_t *) &fullrequest->data;
#else   // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Deserialize response fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    if (pSrvApiHnd->Meddea_setMEDDEAModeRequestHandler != NULL)
    {
        requestCtx.nInterfaceNumber = fp_DataInfo->pMACContext->nInterfaceNumber;
        requestCtx.netType = fp_DataInfo->pMACContext->netType;
        requestCtx.nAddr = fp_DataInfo->pMACContext->nSourceAddr;
        requestCtx.seqId = fullrequest->hdr.seqId;

        pSrvApiHnd->Meddea_setMEDDEAModeRequestHandler(&requestCtx,
                                        requestPayload);
    }
}

static void fs_setMEDDEATimeReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo)
{
    MeddeasetMEDDEATimeProtocolRequestData_t *fullrequest = (MeddeasetMEDDEATimeProtocolRequestData_t *) fp_DataInfo->pu8Data;
    MeddeasetMEDDEATimeRequestData_t *requestPayload = NULL;
    ReqContext_t requestCtx;

    STATIC_ASSERT_SIZE_CHECK(MeddeasetMEDDEATimeProtocolRequestData_t);

    if ((fullrequest == NULL) || (pSrvApiHnd == NULL) || (fp_DataInfo->u16DataSize != sizeof(*fullrequest)))
    {
        return;
    }
#ifndef BIG_ENDIAN_PLATFORM
    requestPayload = (MeddeasetMEDDEATimeRequestData_t *) &fullrequest->data;
#else   // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Deserialize response fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    if (pSrvApiHnd->Meddea_setMEDDEATimeRequestHandler != NULL)
    {
        requestCtx.nInterfaceNumber = fp_DataInfo->pMACContext->nInterfaceNumber;
        requestCtx.netType = fp_DataInfo->pMACContext->netType;
        requestCtx.nAddr = fp_DataInfo->pMACContext->nSourceAddr;
        requestCtx.seqId = fullrequest->hdr.seqId;

        pSrvApiHnd->Meddea_setMEDDEATimeRequestHandler(&requestCtx,
                                        requestPayload);
    }
}

static void fs_setMEDDEADateReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo)
{
    MeddeasetMEDDEADateProtocolRequestData_t *fullrequest = (MeddeasetMEDDEADateProtocolRequestData_t *) fp_DataInfo->pu8Data;
    MeddeasetMEDDEADateRequestData_t *requestPayload = NULL;
    ReqContext_t requestCtx;

    STATIC_ASSERT_SIZE_CHECK(MeddeasetMEDDEADateProtocolRequestData_t);

    if ((fullrequest == NULL) || (pSrvApiHnd == NULL) || (fp_DataInfo->u16DataSize != sizeof(*fullrequest)))
    {
        return;
    }
#ifndef BIG_ENDIAN_PLATFORM
    requestPayload = (MeddeasetMEDDEADateRequestData_t *) &fullrequest->data;
#else   // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Deserialize response fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    if (pSrvApiHnd->Meddea_setMEDDEADateRequestHandler != NULL)
    {
        requestCtx.nInterfaceNumber = fp_DataInfo->pMACContext->nInterfaceNumber;
        requestCtx.netType = fp_DataInfo->pMACContext->netType;
        requestCtx.nAddr = fp_DataInfo->pMACContext->nSourceAddr;
        requestCtx.seqId = fullrequest->hdr.seqId;

        pSrvApiHnd->Meddea_setMEDDEADateRequestHandler(&requestCtx,
                                        requestPayload);
    }
}

static void fs_getMEDDEATimeDateReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo)
{
    MeddeagetMEDDEATimeDateProtocolRequestData_t *fullrequest = (MeddeagetMEDDEATimeDateProtocolRequestData_t *) fp_DataInfo->pu8Data;
    ReqContext_t requestCtx;

    STATIC_ASSERT_SIZE_CHECK(MeddeagetMEDDEATimeDateProtocolRequestData_t);

    if ((fullrequest == NULL) || (pSrvApiHnd == NULL) || (fp_DataInfo->u16DataSize != sizeof(*fullrequest)))
    {
        return;
    }
#ifndef BIG_ENDIAN_PLATFORM
    // no out-arguments specified for response - simple acknowledge call
#else   // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Deserialize response fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    if (pSrvApiHnd->Meddea_getMEDDEATimeDateRequestHandler != NULL)
    {
        requestCtx.nInterfaceNumber = fp_DataInfo->pMACContext->nInterfaceNumber;
        requestCtx.netType = fp_DataInfo->pMACContext->netType;
        requestCtx.nAddr = fp_DataInfo->pMACContext->nSourceAddr;
        requestCtx.seqId = fullrequest->hdr.seqId;

        pSrvApiHnd->Meddea_getMEDDEATimeDateRequestHandler(&requestCtx);
    }
}


/**********************************************************************
 *
 *  Public methods implementation
 *
 **********************************************************************/
void Meddea_registerServerApi(Meddea_ServerApi_t *pSrvApiHandlers)
{
    pSrvApiHnd = pSrvApiHandlers;
}

ESSA_pStack_FunctionProtocolInfo_t Meddea_getServerProtocolDescriptor(void)
{
    return (ESSA_pStack_FunctionProtocolInfo_t) &FP_MeddeaProtocolServerInfo;
}

ESSATMAC_ErrCodes Meddea_getMEDDEAModeResp(
                RespContext_t* ctx,
                const MEDDEA_sMEDDEAParameters_t * const sParameters,
                const MEDDEA_eMEDDEAModes_t eMode
)
{
#ifndef BIG_ENDIAN_PLATFORM
    MeddeagetMEDDEAModeProtocolResponseData_t responseParams;
#else  // #ifndef BIG_ENDIAN_PLATFORM
    uint8_t responseParams[sizeof(MeddeagetMEDDEAModeProtocolResponseData_t)] = { 0 };
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    ESSATMAC_ErrCodes sendResult = ESSATMAC_EC_NULL;

    STATIC_ASSERT_SIZE_CHECK(MeddeagetMEDDEAModeProtocolResponseData_t);

    if ((ctx != NULL) && (sParameters != NULL))
    {
#ifndef BIG_ENDIAN_PLATFORM
        // fill message header
        // RS485 wire protocol also uses LE byte order -> serialization of params is not needed
        responseParams.hdr.protoId = ES_SAT_FUNC_PROTOCOL_ID_MEDDEA;
        responseParams.hdr.funcId  = MEDDEA_GETMEDDEAMODE_FUNCRESP_ID;
        responseParams.hdr.seqId   = ctx->seqId;
        responseParams.hdr.errCode = ESSA_FP_ERRCODE_NOERROR;
        SET_RESPONSE(responseParams.hdr);

        // fill message data
        if (sParameters != NULL)
        {
            responseParams.data.sParameters = *(sParameters);
        }
        else
        {
            (void) memset((void *) &responseParams.data.sParameters,
                          0U,
                          sizeof(responseParams.data.sParameters));
        }
        responseParams.data.eMode = eMode;
#else // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Serialize request fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

        sendResult = ESSA_Stack_SendFrameEx((ESSASNetInterface) ctx->nInterfaceNumber,
                                            ctx->netType,
                                            ctx->nAddr,
                                            ES_SAT_MAC_PROTOCOL_ID_FP_LAYER,
#ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) &responseParams,
#else // #ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) responseParams,
#endif // #ifndef BIG_ENDIAN_PLATFORM
                                            sizeof(MeddeagetMEDDEAModeProtocolResponseData_t),
                                            STACK_SENDFRAME_DEFAULT_PRIO,
                                            (ESSATMAC_DrvResult_Cbk_t) NULL,
                                            (uint32_t *) NULL);
    }

    return sendResult;
}

ESSATMAC_ErrCodes Meddea_setMEDDEAModeResp(
                RespContext_t* ctx,
                const MEDDEA_eCommandExecutionReturn_t eOpResult,
                const MEDDEA_sMEDDEAParameters_t * const sParameters,
                const MEDDEA_eMEDDEAModes_t eMode
)
{
#ifndef BIG_ENDIAN_PLATFORM
    MeddeasetMEDDEAModeProtocolResponseData_t responseParams;
#else  // #ifndef BIG_ENDIAN_PLATFORM
    uint8_t responseParams[sizeof(MeddeasetMEDDEAModeProtocolResponseData_t)] = { 0 };
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    ESSATMAC_ErrCodes sendResult = ESSATMAC_EC_NULL;

    STATIC_ASSERT_SIZE_CHECK(MeddeasetMEDDEAModeProtocolResponseData_t);

    if ((ctx != NULL) && (sParameters != NULL))
    {
#ifndef BIG_ENDIAN_PLATFORM
        // fill message header
        // RS485 wire protocol also uses LE byte order -> serialization of params is not needed
        responseParams.hdr.protoId = ES_SAT_FUNC_PROTOCOL_ID_MEDDEA;
        responseParams.hdr.funcId  = MEDDEA_SETMEDDEAMODE_FUNCRESP_ID;
        responseParams.hdr.seqId   = ctx->seqId;
        responseParams.hdr.errCode = ESSA_FP_ERRCODE_NOERROR;
        SET_RESPONSE(responseParams.hdr);

        // fill message data
        responseParams.data.eOpResult = eOpResult;
        if (sParameters != NULL)
        {
            responseParams.data.sParameters = *(sParameters);
        }
        else
        {
            (void) memset((void *) &responseParams.data.sParameters,
                          0U,
                          sizeof(responseParams.data.sParameters));
        }
        responseParams.data.eMode = eMode;
#else // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Serialize request fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

        sendResult = ESSA_Stack_SendFrameEx((ESSASNetInterface) ctx->nInterfaceNumber,
                                            ctx->netType,
                                            ctx->nAddr,
                                            ES_SAT_MAC_PROTOCOL_ID_FP_LAYER,
#ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) &responseParams,
#else // #ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) responseParams,
#endif // #ifndef BIG_ENDIAN_PLATFORM
                                            sizeof(MeddeasetMEDDEAModeProtocolResponseData_t),
                                            STACK_SENDFRAME_DEFAULT_PRIO,
                                            (ESSATMAC_DrvResult_Cbk_t) NULL,
                                            (uint32_t *) NULL);
    }

    return sendResult;
}

ESSATMAC_ErrCodes Meddea_setMEDDEATimeResp(
                RespContext_t* ctx,
                const MEDDEA_eCommandExecutionReturn_t eExecutionSuccess
)
{
#ifndef BIG_ENDIAN_PLATFORM
    MeddeasetMEDDEATimeProtocolResponseData_t responseParams;
#else  // #ifndef BIG_ENDIAN_PLATFORM
    uint8_t responseParams[sizeof(MeddeasetMEDDEATimeProtocolResponseData_t)] = { 0 };
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    ESSATMAC_ErrCodes sendResult = ESSATMAC_EC_NULL;

    STATIC_ASSERT_SIZE_CHECK(MeddeasetMEDDEATimeProtocolResponseData_t);

    if (ctx != NULL)
    {
#ifndef BIG_ENDIAN_PLATFORM
        // fill message header
        // RS485 wire protocol also uses LE byte order -> serialization of params is not needed
        responseParams.hdr.protoId = ES_SAT_FUNC_PROTOCOL_ID_MEDDEA;
        responseParams.hdr.funcId  = MEDDEA_SETMEDDEATIME_FUNCRESP_ID;
        responseParams.hdr.seqId   = ctx->seqId;
        responseParams.hdr.errCode = ESSA_FP_ERRCODE_NOERROR;
        SET_RESPONSE(responseParams.hdr);

        // fill message data
        responseParams.data.eExecutionSuccess = eExecutionSuccess;
#else // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Serialize request fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

        sendResult = ESSA_Stack_SendFrameEx((ESSASNetInterface) ctx->nInterfaceNumber,
                                            ctx->netType,
                                            ctx->nAddr,
                                            ES_SAT_MAC_PROTOCOL_ID_FP_LAYER,
#ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) &responseParams,
#else // #ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) responseParams,
#endif // #ifndef BIG_ENDIAN_PLATFORM
                                            sizeof(MeddeasetMEDDEATimeProtocolResponseData_t),
                                            STACK_SENDFRAME_DEFAULT_PRIO,
                                            (ESSATMAC_DrvResult_Cbk_t) NULL,
                                            (uint32_t *) NULL);
    }

    return sendResult;
}

ESSATMAC_ErrCodes Meddea_setMEDDEADateResp(
                RespContext_t* ctx,
                const MEDDEA_eCommandExecutionReturn_t eExecutionSuccess
)
{
#ifndef BIG_ENDIAN_PLATFORM
    MeddeasetMEDDEADateProtocolResponseData_t responseParams;
#else  // #ifndef BIG_ENDIAN_PLATFORM
    uint8_t responseParams[sizeof(MeddeasetMEDDEADateProtocolResponseData_t)] = { 0 };
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    ESSATMAC_ErrCodes sendResult = ESSATMAC_EC_NULL;

    STATIC_ASSERT_SIZE_CHECK(MeddeasetMEDDEADateProtocolResponseData_t);

    if (ctx != NULL)
    {
#ifndef BIG_ENDIAN_PLATFORM
        // fill message header
        // RS485 wire protocol also uses LE byte order -> serialization of params is not needed
        responseParams.hdr.protoId = ES_SAT_FUNC_PROTOCOL_ID_MEDDEA;
        responseParams.hdr.funcId  = MEDDEA_SETMEDDEADATE_FUNCRESP_ID;
        responseParams.hdr.seqId   = ctx->seqId;
        responseParams.hdr.errCode = ESSA_FP_ERRCODE_NOERROR;
        SET_RESPONSE(responseParams.hdr);

        // fill message data
        responseParams.data.eExecutionSuccess = eExecutionSuccess;
#else // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Serialize request fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

        sendResult = ESSA_Stack_SendFrameEx((ESSASNetInterface) ctx->nInterfaceNumber,
                                            ctx->netType,
                                            ctx->nAddr,
                                            ES_SAT_MAC_PROTOCOL_ID_FP_LAYER,
#ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) &responseParams,
#else // #ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) responseParams,
#endif // #ifndef BIG_ENDIAN_PLATFORM
                                            sizeof(MeddeasetMEDDEADateProtocolResponseData_t),
                                            STACK_SENDFRAME_DEFAULT_PRIO,
                                            (ESSATMAC_DrvResult_Cbk_t) NULL,
                                            (uint32_t *) NULL);
    }

    return sendResult;
}

ESSATMAC_ErrCodes Meddea_getMEDDEATimeDateResp(
                RespContext_t* ctx,
                const MEDDEA_stime_t * const sTime,
                const MEDDEA_sdate_t * const sDate
)
{
#ifndef BIG_ENDIAN_PLATFORM
    MeddeagetMEDDEATimeDateProtocolResponseData_t responseParams;
#else  // #ifndef BIG_ENDIAN_PLATFORM
    uint8_t responseParams[sizeof(MeddeagetMEDDEATimeDateProtocolResponseData_t)] = { 0 };
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    ESSATMAC_ErrCodes sendResult = ESSATMAC_EC_NULL;

    STATIC_ASSERT_SIZE_CHECK(MeddeagetMEDDEATimeDateProtocolResponseData_t);

    if ((ctx != NULL) && (sTime != NULL) && (sDate != NULL))
    {
#ifndef BIG_ENDIAN_PLATFORM
        // fill message header
        // RS485 wire protocol also uses LE byte order -> serialization of params is not needed
        responseParams.hdr.protoId = ES_SAT_FUNC_PROTOCOL_ID_MEDDEA;
        responseParams.hdr.funcId  = MEDDEA_GETMEDDEATIMEDATE_FUNCRESP_ID;
        responseParams.hdr.seqId   = ctx->seqId;
        responseParams.hdr.errCode = ESSA_FP_ERRCODE_NOERROR;
        SET_RESPONSE(responseParams.hdr);

        // fill message data
        if (sTime != NULL)
        {
            responseParams.data.sTime = *(sTime);
        }
        else
        {
            (void) memset((void *) &responseParams.data.sTime,
                          0U,
                          sizeof(responseParams.data.sTime));
        }
        if (sDate != NULL)
        {
            responseParams.data.sDate = *(sDate);
        }
        else
        {
            (void) memset((void *) &responseParams.data.sDate,
                          0U,
                          sizeof(responseParams.data.sDate));
        }
#else // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Serialize request fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

        sendResult = ESSA_Stack_SendFrameEx((ESSASNetInterface) ctx->nInterfaceNumber,
                                            ctx->netType,
                                            ctx->nAddr,
                                            ES_SAT_MAC_PROTOCOL_ID_FP_LAYER,
#ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) &responseParams,
#else // #ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) responseParams,
#endif // #ifndef BIG_ENDIAN_PLATFORM
                                            sizeof(MeddeagetMEDDEATimeDateProtocolResponseData_t),
                                            STACK_SENDFRAME_DEFAULT_PRIO,
                                            (ESSATMAC_DrvResult_Cbk_t) NULL,
                                            (uint32_t *) NULL);
    }

    return sendResult;
}


