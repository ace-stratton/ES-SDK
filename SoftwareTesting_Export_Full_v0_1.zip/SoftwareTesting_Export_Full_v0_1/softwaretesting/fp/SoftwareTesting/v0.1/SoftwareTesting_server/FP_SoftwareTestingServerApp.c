/*!
********************************************************************************************
* @file FP_SoftwareTestingServerApp.c
* @brief ServerApp implementation template generator
********************************************************************************************
* @version           interface SoftwareTesting v0.1
*
* @copyright         (C) Copyright EnduroSat
*
*                    Contents and presentations are protected world-wide.
*                    Any kind of using, copying etc. is prohibited without prior permission.
*                    All rights - incl. industrial property rights - are reserved.
*
*-------------------------------------------------------------------------------------------
* GENERATOR: org.endurosat.generators.macchiato.binders.Gen_C v2.12
*-------------------------------------------------------------------------------------------
* !!! Please note that this code is fully GENERATED and shall not be manually modified as
* all changes will be overwritten !!!
********************************************************************************************
*/

#include "FP_SoftwareTestingProtocolServer.h"

// @START_USER@ USER_INCLUDES
// Place user includes here to preserve them during merge!!!
// @END_USER@ USER_INCLUDES

/**********************************************************************
 *
 *  Local methods declarations
 *
 **********************************************************************/
// @START_USER@ USER_LOCAL_FUNC_DECL
// Place static function declarations here to preserve them during merge!!!
// @END_USER@ USER_LOCAL_FUNC_DECL
static void SoftwareTesting_OM1_OpModeResetRequestHandlerImpl(ReqContext_t* pReqCtx,
            const SoftwareTestingOM1_OpModeResetRequestData_t* pRequestData);

static void SoftwareTesting_OM2_CommandFloodRequestHandlerImpl(ReqContext_t* pReqCtx,
            const SoftwareTestingOM2_CommandFloodRequestData_t* pRequestData);

static void SoftwareTesting_C1_CommandVerificationRequestHandlerImpl(ReqContext_t* pReqCtx,
            const SoftwareTestingC1_CommandVerificationRequestData_t* pRequestData);

static void SoftwareTesting_C2_InstrumentVerificationRequestHandlerImpl(ReqContext_t* pReqCtx,
            const SoftwareTestingC2_InstrumentVerificationRequestData_t* pRequestData);

static void SoftwareTesting_C4_CommandExecutionRelativeTimingRequestHandlerImpl(ReqContext_t* pReqCtx,
            const SoftwareTestingC4_CommandExecutionRelativeTimingRequestData_t* pRequestData);

static void SoftwareTesting_C5_CommandExecutionAbsoluteTimingRequestHandlerImpl(ReqContext_t* pReqCtx,
            const SoftwareTestingC5_CommandExecutionAbsoluteTimingRequestData_t* pRequestData);

static void SoftwareTesting_getCommandExecutionTimingRequestHandlerImpl(ReqContext_t* pReqCtx);

static void SoftwareTesting_C6_getTimeRequestHandlerImpl(ReqContext_t* pReqCtx);


/**********************************************************************
 *
 *  Local variables
 *
 **********************************************************************/
// @START_USER@ USER_LOCAL_VARS_DECL
// Place static variable declarations here to preserve them during merge!!!
// @END_USER@ USER_LOCAL_VARS_DECL

static SoftwareTesting_ServerApi_t SoftwareTestingServerApiCtx =
{
  .SoftwareTesting_OM1_OpModeResetRequestHandler = (pfSoftwareTesting_OM1_OpModeResetRequestHandler_t) SoftwareTesting_OM1_OpModeResetRequestHandlerImpl,
  .SoftwareTesting_OM2_CommandFloodRequestHandler = (pfSoftwareTesting_OM2_CommandFloodRequestHandler_t) SoftwareTesting_OM2_CommandFloodRequestHandlerImpl,
  .SoftwareTesting_C1_CommandVerificationRequestHandler = (pfSoftwareTesting_C1_CommandVerificationRequestHandler_t) SoftwareTesting_C1_CommandVerificationRequestHandlerImpl,
  .SoftwareTesting_C2_InstrumentVerificationRequestHandler = (pfSoftwareTesting_C2_InstrumentVerificationRequestHandler_t) SoftwareTesting_C2_InstrumentVerificationRequestHandlerImpl,
  .SoftwareTesting_C4_CommandExecutionRelativeTimingRequestHandler = (pfSoftwareTesting_C4_CommandExecutionRelativeTimingRequestHandler_t) SoftwareTesting_C4_CommandExecutionRelativeTimingRequestHandlerImpl,
  .SoftwareTesting_C5_CommandExecutionAbsoluteTimingRequestHandler = (pfSoftwareTesting_C5_CommandExecutionAbsoluteTimingRequestHandler_t) SoftwareTesting_C5_CommandExecutionAbsoluteTimingRequestHandlerImpl,
  .SoftwareTesting_getCommandExecutionTimingRequestHandler = (pfSoftwareTesting_getCommandExecutionTimingRequestHandler_t) SoftwareTesting_getCommandExecutionTimingRequestHandlerImpl,
  .SoftwareTesting_C6_getTimeRequestHandler = (pfSoftwareTesting_C6_getTimeRequestHandler_t) SoftwareTesting_C6_getTimeRequestHandlerImpl
};

/**********************************************************************
 *
 *  Local methods implementation
 *
 **********************************************************************/
// @START_USER@ USER_LOCAL_FUNC_IMPL
// Place static functions implementation here to preserve it during merge!!!
// @END_USER@ USER_LOCAL_FUNC_IMPL

// @START@ Request handler for method SoftwareTesting::OM1_OpModeReset (ID = 0x00000001)
static void SoftwareTesting_OM1_OpModeResetRequestHandlerImpl(ReqContext_t *pReqCtx,
            const SoftwareTestingOM1_OpModeResetRequestData_t* pRequestData)
{
    ESSATMAC_ErrCodes respResult;
    RespContext_t respCtx;
    SOFTWARETESTING_eOpModes_t eOpMode;

    // @USER_VAR_SECTION_START@SoftwareTesting::OM1_OpModeReset@
    // Put your local variables in this section to preserve during merge!
    // @USER_VAR_SECTION_END@SoftwareTesting::OM1_OpModeReset@

    if ((pReqCtx != NULL) && (pRequestData != NULL))
    {
        respCtx.nInterfaceNumber = pReqCtx->nInterfaceNumber;
        respCtx.netType = pReqCtx->netType;
        respCtx.nAddr = pReqCtx->nAddr;
        respCtx.seqId = pReqCtx->seqId;

        // @USER_CODE_SECTION_START@SoftwareTesting::OM1_OpModeReset@
        
        // TODO: Put your implementation to handle the
        // received server response here!
        
        // @USER_CODE_SECTION_END@SoftwareTesting::OM1_OpModeReset@

        respResult = SoftwareTesting_OM1_OpModeResetResp(
                        &respCtx,
                        eOpMode
                     );

        if (respResult != ESSATMAC_EC_OK)
            TRACE_ERROR(ES_SAT_FUNC_PROTOCOL_ID_SOFTWARETESTING, SOFTWARETESTING_OM1_OPMODERESET_FUNCRESP_ID, respResult);
    }
}
// @END@ Request handler for method SoftwareTesting::OM1_OpModeReset (ID = 0x00000001)

// @START@ Request handler for method SoftwareTesting::OM2_CommandFlood (ID = 0x00000002)
static void SoftwareTesting_OM2_CommandFloodRequestHandlerImpl(ReqContext_t *pReqCtx,
            const SoftwareTestingOM2_CommandFloodRequestData_t* pRequestData)
{
    ESSATMAC_ErrCodes respResult;
    RespContext_t respCtx;
    SOFTWARETESTING_sCommandCount_t sNumOfCommandsRecieved;

    // @USER_VAR_SECTION_START@SoftwareTesting::OM2_CommandFlood@
    // Put your local variables in this section to preserve during merge!
    // @USER_VAR_SECTION_END@SoftwareTesting::OM2_CommandFlood@

    if ((pReqCtx != NULL) && (pRequestData != NULL))
    {
        respCtx.nInterfaceNumber = pReqCtx->nInterfaceNumber;
        respCtx.netType = pReqCtx->netType;
        respCtx.nAddr = pReqCtx->nAddr;
        respCtx.seqId = pReqCtx->seqId;

        // @USER_CODE_SECTION_START@SoftwareTesting::OM2_CommandFlood@
        
        // TODO: Put your implementation to handle the
        // received server response here!
        
        // @USER_CODE_SECTION_END@SoftwareTesting::OM2_CommandFlood@

        respResult = SoftwareTesting_OM2_CommandFloodResp(
                        &respCtx,
                        &sNumOfCommandsRecieved
                     );

        if (respResult != ESSATMAC_EC_OK)
            TRACE_ERROR(ES_SAT_FUNC_PROTOCOL_ID_SOFTWARETESTING, SOFTWARETESTING_OM2_COMMANDFLOOD_FUNCRESP_ID, respResult);
    }
}
// @END@ Request handler for method SoftwareTesting::OM2_CommandFlood (ID = 0x00000002)

// @START@ Request handler for method SoftwareTesting::C1_CommandVerification (ID = 0x00000003)
static void SoftwareTesting_C1_CommandVerificationRequestHandlerImpl(ReqContext_t *pReqCtx,
            const SoftwareTestingC1_CommandVerificationRequestData_t* pRequestData)
{
    ESSATMAC_ErrCodes respResult;
    RespContext_t respCtx;
    SOFTWARETESTING_eVerificationModes_t eVerificationModeReturn;
    SOFTWARETESTING_sCommandCount_t sNumOfCommandsRecieved;
    SOFTWARETESTING_sEchoValue_t sEchoReturn;

    // @USER_VAR_SECTION_START@SoftwareTesting::C1_CommandVerification@
    // Put your local variables in this section to preserve during merge!
    // @USER_VAR_SECTION_END@SoftwareTesting::C1_CommandVerification@

    if ((pReqCtx != NULL) && (pRequestData != NULL))
    {
        respCtx.nInterfaceNumber = pReqCtx->nInterfaceNumber;
        respCtx.netType = pReqCtx->netType;
        respCtx.nAddr = pReqCtx->nAddr;
        respCtx.seqId = pReqCtx->seqId;

        // @USER_CODE_SECTION_START@SoftwareTesting::C1_CommandVerification@
        
        // TODO: Put your implementation to handle the
        // received server response here!
        
        // @USER_CODE_SECTION_END@SoftwareTesting::C1_CommandVerification@

        respResult = SoftwareTesting_C1_CommandVerificationResp(
                        &respCtx,
                        eVerificationModeReturn,
                        &sNumOfCommandsRecieved,
                        &sEchoReturn
                     );

        if (respResult != ESSATMAC_EC_OK)
            TRACE_ERROR(ES_SAT_FUNC_PROTOCOL_ID_SOFTWARETESTING, SOFTWARETESTING_C1_COMMANDVERIFICATION_FUNCRESP_ID, respResult);
    }
}
// @END@ Request handler for method SoftwareTesting::C1_CommandVerification (ID = 0x00000003)

// @START@ Request handler for method SoftwareTesting::C2_InstrumentVerification (ID = 0x00000004)
static void SoftwareTesting_C2_InstrumentVerificationRequestHandlerImpl(ReqContext_t *pReqCtx,
            const SoftwareTestingC2_InstrumentVerificationRequestData_t* pRequestData)
{
    ESSATMAC_ErrCodes respResult;
    RespContext_t respCtx;
    SOFTWARETESTING_eInstrumentOpt_t eInstrumentSelectionReturn;
    SOFTWARETESTING_eInstrumentPower_t ePowerSelectionReturn;
    SOFTWARETESTING_sCommandCount_t sNumOfCommandsRecieved;
    SOFTWARETESTING_sEchoValue_t sEchoReturn;

    // @USER_VAR_SECTION_START@SoftwareTesting::C2_InstrumentVerification@
    // Put your local variables in this section to preserve during merge!
    // @USER_VAR_SECTION_END@SoftwareTesting::C2_InstrumentVerification@

    if ((pReqCtx != NULL) && (pRequestData != NULL))
    {
        respCtx.nInterfaceNumber = pReqCtx->nInterfaceNumber;
        respCtx.netType = pReqCtx->netType;
        respCtx.nAddr = pReqCtx->nAddr;
        respCtx.seqId = pReqCtx->seqId;

        // @USER_CODE_SECTION_START@SoftwareTesting::C2_InstrumentVerification@
        
        // TODO: Put your implementation to handle the
        // received server response here!
        
        // @USER_CODE_SECTION_END@SoftwareTesting::C2_InstrumentVerification@

        respResult = SoftwareTesting_C2_InstrumentVerificationResp(
                        &respCtx,
                        eInstrumentSelectionReturn,
                        ePowerSelectionReturn,
                        &sNumOfCommandsRecieved,
                        &sEchoReturn
                     );

        if (respResult != ESSATMAC_EC_OK)
            TRACE_ERROR(ES_SAT_FUNC_PROTOCOL_ID_SOFTWARETESTING, SOFTWARETESTING_C2_INSTRUMENTVERIFICATION_FUNCRESP_ID, respResult);
    }
}
// @END@ Request handler for method SoftwareTesting::C2_InstrumentVerification (ID = 0x00000004)

// @START@ Request handler for method SoftwareTesting::C4_CommandExecutionRelativeTiming (ID = 0x00000005)
static void SoftwareTesting_C4_CommandExecutionRelativeTimingRequestHandlerImpl(ReqContext_t *pReqCtx,
            const SoftwareTestingC4_CommandExecutionRelativeTimingRequestData_t* pRequestData)
{
    ESSATMAC_ErrCodes respResult;
    RespContext_t respCtx;
    SOFTWARETESTING_eCommandExecutionReturn_t eCommandReturn;

    // @USER_VAR_SECTION_START@SoftwareTesting::C4_CommandExecutionRelativeTiming@
    // Put your local variables in this section to preserve during merge!
    // @USER_VAR_SECTION_END@SoftwareTesting::C4_CommandExecutionRelativeTiming@

    if ((pReqCtx != NULL) && (pRequestData != NULL))
    {
        respCtx.nInterfaceNumber = pReqCtx->nInterfaceNumber;
        respCtx.netType = pReqCtx->netType;
        respCtx.nAddr = pReqCtx->nAddr;
        respCtx.seqId = pReqCtx->seqId;

        // @USER_CODE_SECTION_START@SoftwareTesting::C4_CommandExecutionRelativeTiming@
        
        // TODO: Put your implementation to handle the
        // received server response here!
        
        // @USER_CODE_SECTION_END@SoftwareTesting::C4_CommandExecutionRelativeTiming@

        respResult = SoftwareTesting_C4_CommandExecutionRelativeTimingResp(
                        &respCtx,
                        eCommandReturn
                     );

        if (respResult != ESSATMAC_EC_OK)
            TRACE_ERROR(ES_SAT_FUNC_PROTOCOL_ID_SOFTWARETESTING, SOFTWARETESTING_C4_COMMANDEXECUTIONRELATIVETIMING_FUNCRESP_ID, respResult);
    }
}
// @END@ Request handler for method SoftwareTesting::C4_CommandExecutionRelativeTiming (ID = 0x00000005)

// @START@ Request handler for method SoftwareTesting::C5_CommandExecutionAbsoluteTiming (ID = 0x00000006)
static void SoftwareTesting_C5_CommandExecutionAbsoluteTimingRequestHandlerImpl(ReqContext_t *pReqCtx,
            const SoftwareTestingC5_CommandExecutionAbsoluteTimingRequestData_t* pRequestData)
{
    ESSATMAC_ErrCodes respResult;
    RespContext_t respCtx;
    SOFTWARETESTING_eCommandExecutionReturn_t eCommandReturn;

    // @USER_VAR_SECTION_START@SoftwareTesting::C5_CommandExecutionAbsoluteTiming@
    // Put your local variables in this section to preserve during merge!
    // @USER_VAR_SECTION_END@SoftwareTesting::C5_CommandExecutionAbsoluteTiming@

    if ((pReqCtx != NULL) && (pRequestData != NULL))
    {
        respCtx.nInterfaceNumber = pReqCtx->nInterfaceNumber;
        respCtx.netType = pReqCtx->netType;
        respCtx.nAddr = pReqCtx->nAddr;
        respCtx.seqId = pReqCtx->seqId;

        // @USER_CODE_SECTION_START@SoftwareTesting::C5_CommandExecutionAbsoluteTiming@
        
        // TODO: Put your implementation to handle the
        // received server response here!
        
        // @USER_CODE_SECTION_END@SoftwareTesting::C5_CommandExecutionAbsoluteTiming@

        respResult = SoftwareTesting_C5_CommandExecutionAbsoluteTimingResp(
                        &respCtx,
                        eCommandReturn
                     );

        if (respResult != ESSATMAC_EC_OK)
            TRACE_ERROR(ES_SAT_FUNC_PROTOCOL_ID_SOFTWARETESTING, SOFTWARETESTING_C5_COMMANDEXECUTIONABSOLUTETIMING_FUNCRESP_ID, respResult);
    }
}
// @END@ Request handler for method SoftwareTesting::C5_CommandExecutionAbsoluteTiming (ID = 0x00000006)

// @START@ Request handler for method SoftwareTesting::getCommandExecutionTiming (ID = 0x00000007)
static void SoftwareTesting_getCommandExecutionTimingRequestHandlerImpl(ReqContext_t* pReqCtx)
{
    ESSATMAC_ErrCodes respResult;
    RespContext_t respCtx;
    SOFTWARETESTING_sCommandCount_t sNumOfCommandsRecieved;
    SOFTWARETESTING_sEchoValue_t sEchoReturn;
    SOFTWARETESTING_sdate_t sDateCommandReturn;
    SOFTWARETESTING_stime_t sTimeCommandReturn;

    // @USER_VAR_SECTION_START@SoftwareTesting::getCommandExecutionTiming@
    // Put your local variables in this section to preserve during merge!
    // @USER_VAR_SECTION_END@SoftwareTesting::getCommandExecutionTiming@

    if (pReqCtx != NULL)
    {
        respCtx.nInterfaceNumber = pReqCtx->nInterfaceNumber;
        respCtx.netType = pReqCtx->netType;
        respCtx.nAddr = pReqCtx->nAddr;
        respCtx.seqId = pReqCtx->seqId;

        // @USER_CODE_SECTION_START@SoftwareTesting::getCommandExecutionTiming@
        
        // TODO: Put your implementation to handle the
        // received server response here!
        
        // @USER_CODE_SECTION_END@SoftwareTesting::getCommandExecutionTiming@

        respResult = SoftwareTesting_getCommandExecutionTimingResp(
                        &respCtx,
                        &sNumOfCommandsRecieved,
                        &sEchoReturn,
                        &sDateCommandReturn,
                        &sTimeCommandReturn
                     );

        if (respResult != ESSATMAC_EC_OK)
            TRACE_ERROR(ES_SAT_FUNC_PROTOCOL_ID_SOFTWARETESTING, SOFTWARETESTING_GETCOMMANDEXECUTIONTIMING_FUNCRESP_ID, respResult);
    }
}
// @END@ Request handler for method SoftwareTesting::getCommandExecutionTiming (ID = 0x00000007)

// @START@ Request handler for method SoftwareTesting::C6_getTime (ID = 0x00000008)
static void SoftwareTesting_C6_getTimeRequestHandlerImpl(ReqContext_t* pReqCtx)
{
    ESSATMAC_ErrCodes respResult;
    RespContext_t respCtx;
    uint32_t u32UpTime;
    SOFTWARETESTING_sdate_t sDate;
    SOFTWARETESTING_stime_t sTime;

    // @USER_VAR_SECTION_START@SoftwareTesting::C6_getTime@
    // Put your local variables in this section to preserve during merge!
    // @USER_VAR_SECTION_END@SoftwareTesting::C6_getTime@

    if (pReqCtx != NULL)
    {
        respCtx.nInterfaceNumber = pReqCtx->nInterfaceNumber;
        respCtx.netType = pReqCtx->netType;
        respCtx.nAddr = pReqCtx->nAddr;
        respCtx.seqId = pReqCtx->seqId;

        // @USER_CODE_SECTION_START@SoftwareTesting::C6_getTime@
        
        // TODO: Put your implementation to handle the
        // received server response here!
        
        // @USER_CODE_SECTION_END@SoftwareTesting::C6_getTime@

        respResult = SoftwareTesting_C6_getTimeResp(
                        &respCtx,
                        u32UpTime,
                        &sDate,
                        &sTime
                     );

        if (respResult != ESSATMAC_EC_OK)
            TRACE_ERROR(ES_SAT_FUNC_PROTOCOL_ID_SOFTWARETESTING, SOFTWARETESTING_C6_GETTIME_FUNCRESP_ID, respResult);
    }
}
// @END@ Request handler for method SoftwareTesting::C6_getTime (ID = 0x00000008)


/**********************************************************************
 *
 *  Public functions
 *
 **********************************************************************/
void SoftwareTestingServerAppInit(void)
{
    SoftwareTesting_registerServerApi(&SoftwareTestingServerApiCtx);
}
