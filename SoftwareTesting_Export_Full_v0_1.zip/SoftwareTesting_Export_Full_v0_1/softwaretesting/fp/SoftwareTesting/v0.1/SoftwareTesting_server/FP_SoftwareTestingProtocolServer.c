/*!
********************************************************************************************
* @file FP_SoftwareTestingProtocolServer.c
* @brief ESSA Stack server-side implementation
********************************************************************************************
* @version           interface SoftwareTesting v0.1
*
* @copyright         (C) Copyright EnduroSat
*
*                    Contents and presentations are protected world-wide.
*                    Any kind of using, copying etc. is prohibited without prior permission.
*                    All rights - incl. industrial property rights - are reserved.
*
*-------------------------------------------------------------------------------------------
* GENERATOR: org.endurosat.generators.macchiato.binders.Gen_C v2.12
*-------------------------------------------------------------------------------------------
* !!! Please note that this code is fully GENERATED and shall not be manually modified as
* all changes will be overwritten !!!
********************************************************************************************
*/

#include "FP_SoftwareTestingProtocolServer.h"
#include "FP_common/FP_ProtocolServerCommon.h"

#define SoftwareTesting_PROTOCOL_VERSION_MAJOR   ((uint8_t) 0)
#define SoftwareTesting_PROTOCOL_VERSION_MINOR   ((uint8_t) 1)

/**********************************************************************
 *
 *  Local type definitions
 *
 **********************************************************************/
typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    SoftwareTestingOM1_OpModeResetRequestData_t data;
} PACKED_STRUCT SoftwareTestingOM1_OpModeResetProtocolRequestData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    SoftwareTestingOM1_OpModeResetResponseData_t data;
} PACKED_STRUCT SoftwareTestingOM1_OpModeResetProtocolResponseData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    SoftwareTestingOM2_CommandFloodRequestData_t data;
} PACKED_STRUCT SoftwareTestingOM2_CommandFloodProtocolRequestData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    SoftwareTestingOM2_CommandFloodResponseData_t data;
} PACKED_STRUCT SoftwareTestingOM2_CommandFloodProtocolResponseData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    SoftwareTestingC1_CommandVerificationRequestData_t data;
} PACKED_STRUCT SoftwareTestingC1_CommandVerificationProtocolRequestData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    SoftwareTestingC1_CommandVerificationResponseData_t data;
} PACKED_STRUCT SoftwareTestingC1_CommandVerificationProtocolResponseData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    SoftwareTestingC2_InstrumentVerificationRequestData_t data;
} PACKED_STRUCT SoftwareTestingC2_InstrumentVerificationProtocolRequestData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    SoftwareTestingC2_InstrumentVerificationResponseData_t data;
} PACKED_STRUCT SoftwareTestingC2_InstrumentVerificationProtocolResponseData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    SoftwareTestingC4_CommandExecutionRelativeTimingRequestData_t data;
} PACKED_STRUCT SoftwareTestingC4_CommandExecutionRelativeTimingProtocolRequestData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    SoftwareTestingC4_CommandExecutionRelativeTimingResponseData_t data;
} PACKED_STRUCT SoftwareTestingC4_CommandExecutionRelativeTimingProtocolResponseData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    SoftwareTestingC5_CommandExecutionAbsoluteTimingRequestData_t data;
} PACKED_STRUCT SoftwareTestingC5_CommandExecutionAbsoluteTimingProtocolRequestData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    SoftwareTestingC5_CommandExecutionAbsoluteTimingResponseData_t data;
} PACKED_STRUCT SoftwareTestingC5_CommandExecutionAbsoluteTimingProtocolResponseData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
} PACKED_STRUCT SoftwareTestinggetCommandExecutionTimingProtocolRequestData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    SoftwareTestinggetCommandExecutionTimingResponseData_t data;
} PACKED_STRUCT SoftwareTestinggetCommandExecutionTimingProtocolResponseData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
} PACKED_STRUCT SoftwareTestingC6_getTimeProtocolRequestData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    SoftwareTestingC6_getTimeResponseData_t data;
} PACKED_STRUCT SoftwareTestingC6_getTimeProtocolResponseData_t;


/**********************************************************************
 *
 *  Static methods declarations
 *
 **********************************************************************/
static bool fs_HandleData(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo);
static void fs_OM1_OpModeResetReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo);
static void fs_OM2_CommandFloodReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo);
static void fs_C1_CommandVerificationReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo);
static void fs_C2_InstrumentVerificationReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo);
static void fs_C4_CommandExecutionRelativeTimingReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo);
static void fs_C5_CommandExecutionAbsoluteTimingReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo);
static void fs_getCommandExecutionTimingReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo);
static void fs_C6_getTimeReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo);

/**********************************************************************
 *
 *  Public variable definitions
 *
 **********************************************************************/
const ESSA_Stack_FunctionProtocolInfo_t FP_SoftwareTestingProtocolServerInfo = {
    .u16ProtocolId    = ES_SAT_FUNC_PROTOCOL_ID_SOFTWARETESTING,
    .pfDataHandlerCbk = fs_HandleData
};

/**********************************************************************
 *
 *  Static variable definitions
 *
 **********************************************************************/
static SoftwareTesting_ServerApi_t *pSrvApiHnd = NULL;

static const ProtocolFuncArrayEntry_t fs_aFuncArray[] = {
    { SOFTWARETESTING_OM1_OPMODERESET_FUNC_ID, fs_OM1_OpModeResetReq },
    { SOFTWARETESTING_OM2_COMMANDFLOOD_FUNC_ID, fs_OM2_CommandFloodReq },
    { SOFTWARETESTING_C1_COMMANDVERIFICATION_FUNC_ID, fs_C1_CommandVerificationReq },
    { SOFTWARETESTING_C2_INSTRUMENTVERIFICATION_FUNC_ID, fs_C2_InstrumentVerificationReq },
    { SOFTWARETESTING_C4_COMMANDEXECUTIONRELATIVETIMING_FUNC_ID, fs_C4_CommandExecutionRelativeTimingReq },
    { SOFTWARETESTING_C5_COMMANDEXECUTIONABSOLUTETIMING_FUNC_ID, fs_C5_CommandExecutionAbsoluteTimingReq },
    { SOFTWARETESTING_GETCOMMANDEXECUTIONTIMING_FUNC_ID, fs_getCommandExecutionTimingReq },
    { SOFTWARETESTING_C6_GETTIME_FUNC_ID, fs_C6_getTimeReq }
};

/**********************************************************************
 *
 *  Static methods implementation
 *
 **********************************************************************/
static bool fs_HandleData(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo)
{
    ESSA_Stack_FP_MsgHdr_t *pHdr = NULL;
    bool bIsFuncSupported = false;
    uint8_t i;

    // Basic header validity check
    if ((fp_DataInfo == NULL) ||
        (fp_DataInfo->u16DataSize < sizeof(ESSA_Stack_FP_MsgHdr_t)) ||
        (fp_DataInfo->pu8Data == NULL))
    {
        return false;
    }

    pHdr = (ESSA_Stack_FP_MsgHdr_t *) fp_DataInfo->pu8Data;

    if (IS_REQUEST(*pHdr))
    {
        for (i = 0; i < COUNT_OF(fs_aFuncArray); i++)
        {
            if (fs_aFuncArray[i].funcId == pHdr->funcId)
            {
                if (fs_aFuncArray[i].pfFunc != NULL)
                {
                    bIsFuncSupported = true;
                    fs_aFuncArray[i].pfFunc(fp_DataInfo);
                }

                break;
            }
        }

        if (!bIsFuncSupported)
            (void) ProtocolSendErrorResp(fp_DataInfo, (uint8_t) ESSA_FP_ERRCODE_FUNC_NOT_SUPPORTED);
    }

    return bIsFuncSupported;
}

static void fs_OM1_OpModeResetReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo)
{
    SoftwareTestingOM1_OpModeResetProtocolRequestData_t *fullrequest = (SoftwareTestingOM1_OpModeResetProtocolRequestData_t *) fp_DataInfo->pu8Data;
    SoftwareTestingOM1_OpModeResetRequestData_t *requestPayload = NULL;
    ReqContext_t requestCtx;

    STATIC_ASSERT_SIZE_CHECK(SoftwareTestingOM1_OpModeResetProtocolRequestData_t);

    if ((fullrequest == NULL) || (pSrvApiHnd == NULL) || (fp_DataInfo->u16DataSize != sizeof(*fullrequest)))
    {
        return;
    }
#ifndef BIG_ENDIAN_PLATFORM
    requestPayload = (SoftwareTestingOM1_OpModeResetRequestData_t *) &fullrequest->data;
#else   // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Deserialize response fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    if (pSrvApiHnd->SoftwareTesting_OM1_OpModeResetRequestHandler != NULL)
    {
        requestCtx.nInterfaceNumber = fp_DataInfo->pMACContext->nInterfaceNumber;
        requestCtx.netType = fp_DataInfo->pMACContext->netType;
        requestCtx.nAddr = fp_DataInfo->pMACContext->nSourceAddr;
        requestCtx.seqId = fullrequest->hdr.seqId;

        pSrvApiHnd->SoftwareTesting_OM1_OpModeResetRequestHandler(&requestCtx,
                                        requestPayload);
    }
}

static void fs_OM2_CommandFloodReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo)
{
    SoftwareTestingOM2_CommandFloodProtocolRequestData_t *fullrequest = (SoftwareTestingOM2_CommandFloodProtocolRequestData_t *) fp_DataInfo->pu8Data;
    SoftwareTestingOM2_CommandFloodRequestData_t *requestPayload = NULL;
    ReqContext_t requestCtx;

    STATIC_ASSERT_SIZE_CHECK(SoftwareTestingOM2_CommandFloodProtocolRequestData_t);

    if ((fullrequest == NULL) || (pSrvApiHnd == NULL) || (fp_DataInfo->u16DataSize != sizeof(*fullrequest)))
    {
        return;
    }
#ifndef BIG_ENDIAN_PLATFORM
    requestPayload = (SoftwareTestingOM2_CommandFloodRequestData_t *) &fullrequest->data;
#else   // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Deserialize response fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    if (pSrvApiHnd->SoftwareTesting_OM2_CommandFloodRequestHandler != NULL)
    {
        requestCtx.nInterfaceNumber = fp_DataInfo->pMACContext->nInterfaceNumber;
        requestCtx.netType = fp_DataInfo->pMACContext->netType;
        requestCtx.nAddr = fp_DataInfo->pMACContext->nSourceAddr;
        requestCtx.seqId = fullrequest->hdr.seqId;

        pSrvApiHnd->SoftwareTesting_OM2_CommandFloodRequestHandler(&requestCtx,
                                        requestPayload);
    }
}

static void fs_C1_CommandVerificationReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo)
{
    SoftwareTestingC1_CommandVerificationProtocolRequestData_t *fullrequest = (SoftwareTestingC1_CommandVerificationProtocolRequestData_t *) fp_DataInfo->pu8Data;
    SoftwareTestingC1_CommandVerificationRequestData_t *requestPayload = NULL;
    ReqContext_t requestCtx;

    STATIC_ASSERT_SIZE_CHECK(SoftwareTestingC1_CommandVerificationProtocolRequestData_t);

    if ((fullrequest == NULL) || (pSrvApiHnd == NULL) || (fp_DataInfo->u16DataSize != sizeof(*fullrequest)))
    {
        return;
    }
#ifndef BIG_ENDIAN_PLATFORM
    requestPayload = (SoftwareTestingC1_CommandVerificationRequestData_t *) &fullrequest->data;
#else   // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Deserialize response fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    if (pSrvApiHnd->SoftwareTesting_C1_CommandVerificationRequestHandler != NULL)
    {
        requestCtx.nInterfaceNumber = fp_DataInfo->pMACContext->nInterfaceNumber;
        requestCtx.netType = fp_DataInfo->pMACContext->netType;
        requestCtx.nAddr = fp_DataInfo->pMACContext->nSourceAddr;
        requestCtx.seqId = fullrequest->hdr.seqId;

        pSrvApiHnd->SoftwareTesting_C1_CommandVerificationRequestHandler(&requestCtx,
                                        requestPayload);
    }
}

static void fs_C2_InstrumentVerificationReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo)
{
    SoftwareTestingC2_InstrumentVerificationProtocolRequestData_t *fullrequest = (SoftwareTestingC2_InstrumentVerificationProtocolRequestData_t *) fp_DataInfo->pu8Data;
    SoftwareTestingC2_InstrumentVerificationRequestData_t *requestPayload = NULL;
    ReqContext_t requestCtx;

    STATIC_ASSERT_SIZE_CHECK(SoftwareTestingC2_InstrumentVerificationProtocolRequestData_t);

    if ((fullrequest == NULL) || (pSrvApiHnd == NULL) || (fp_DataInfo->u16DataSize != sizeof(*fullrequest)))
    {
        return;
    }
#ifndef BIG_ENDIAN_PLATFORM
    requestPayload = (SoftwareTestingC2_InstrumentVerificationRequestData_t *) &fullrequest->data;
#else   // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Deserialize response fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    if (pSrvApiHnd->SoftwareTesting_C2_InstrumentVerificationRequestHandler != NULL)
    {
        requestCtx.nInterfaceNumber = fp_DataInfo->pMACContext->nInterfaceNumber;
        requestCtx.netType = fp_DataInfo->pMACContext->netType;
        requestCtx.nAddr = fp_DataInfo->pMACContext->nSourceAddr;
        requestCtx.seqId = fullrequest->hdr.seqId;

        pSrvApiHnd->SoftwareTesting_C2_InstrumentVerificationRequestHandler(&requestCtx,
                                        requestPayload);
    }
}

static void fs_C4_CommandExecutionRelativeTimingReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo)
{
    SoftwareTestingC4_CommandExecutionRelativeTimingProtocolRequestData_t *fullrequest = (SoftwareTestingC4_CommandExecutionRelativeTimingProtocolRequestData_t *) fp_DataInfo->pu8Data;
    SoftwareTestingC4_CommandExecutionRelativeTimingRequestData_t *requestPayload = NULL;
    ReqContext_t requestCtx;

    STATIC_ASSERT_SIZE_CHECK(SoftwareTestingC4_CommandExecutionRelativeTimingProtocolRequestData_t);

    if ((fullrequest == NULL) || (pSrvApiHnd == NULL) || (fp_DataInfo->u16DataSize != sizeof(*fullrequest)))
    {
        return;
    }
#ifndef BIG_ENDIAN_PLATFORM
    requestPayload = (SoftwareTestingC4_CommandExecutionRelativeTimingRequestData_t *) &fullrequest->data;
#else   // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Deserialize response fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    if (pSrvApiHnd->SoftwareTesting_C4_CommandExecutionRelativeTimingRequestHandler != NULL)
    {
        requestCtx.nInterfaceNumber = fp_DataInfo->pMACContext->nInterfaceNumber;
        requestCtx.netType = fp_DataInfo->pMACContext->netType;
        requestCtx.nAddr = fp_DataInfo->pMACContext->nSourceAddr;
        requestCtx.seqId = fullrequest->hdr.seqId;

        pSrvApiHnd->SoftwareTesting_C4_CommandExecutionRelativeTimingRequestHandler(&requestCtx,
                                        requestPayload);
    }
}

static void fs_C5_CommandExecutionAbsoluteTimingReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo)
{
    SoftwareTestingC5_CommandExecutionAbsoluteTimingProtocolRequestData_t *fullrequest = (SoftwareTestingC5_CommandExecutionAbsoluteTimingProtocolRequestData_t *) fp_DataInfo->pu8Data;
    SoftwareTestingC5_CommandExecutionAbsoluteTimingRequestData_t *requestPayload = NULL;
    ReqContext_t requestCtx;

    STATIC_ASSERT_SIZE_CHECK(SoftwareTestingC5_CommandExecutionAbsoluteTimingProtocolRequestData_t);

    if ((fullrequest == NULL) || (pSrvApiHnd == NULL) || (fp_DataInfo->u16DataSize != sizeof(*fullrequest)))
    {
        return;
    }
#ifndef BIG_ENDIAN_PLATFORM
    requestPayload = (SoftwareTestingC5_CommandExecutionAbsoluteTimingRequestData_t *) &fullrequest->data;
#else   // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Deserialize response fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    if (pSrvApiHnd->SoftwareTesting_C5_CommandExecutionAbsoluteTimingRequestHandler != NULL)
    {
        requestCtx.nInterfaceNumber = fp_DataInfo->pMACContext->nInterfaceNumber;
        requestCtx.netType = fp_DataInfo->pMACContext->netType;
        requestCtx.nAddr = fp_DataInfo->pMACContext->nSourceAddr;
        requestCtx.seqId = fullrequest->hdr.seqId;

        pSrvApiHnd->SoftwareTesting_C5_CommandExecutionAbsoluteTimingRequestHandler(&requestCtx,
                                        requestPayload);
    }
}

static void fs_getCommandExecutionTimingReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo)
{
    SoftwareTestinggetCommandExecutionTimingProtocolRequestData_t *fullrequest = (SoftwareTestinggetCommandExecutionTimingProtocolRequestData_t *) fp_DataInfo->pu8Data;
    ReqContext_t requestCtx;

    STATIC_ASSERT_SIZE_CHECK(SoftwareTestinggetCommandExecutionTimingProtocolRequestData_t);

    if ((fullrequest == NULL) || (pSrvApiHnd == NULL) || (fp_DataInfo->u16DataSize != sizeof(*fullrequest)))
    {
        return;
    }
#ifndef BIG_ENDIAN_PLATFORM
    // no out-arguments specified for response - simple acknowledge call
#else   // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Deserialize response fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    if (pSrvApiHnd->SoftwareTesting_getCommandExecutionTimingRequestHandler != NULL)
    {
        requestCtx.nInterfaceNumber = fp_DataInfo->pMACContext->nInterfaceNumber;
        requestCtx.netType = fp_DataInfo->pMACContext->netType;
        requestCtx.nAddr = fp_DataInfo->pMACContext->nSourceAddr;
        requestCtx.seqId = fullrequest->hdr.seqId;

        pSrvApiHnd->SoftwareTesting_getCommandExecutionTimingRequestHandler(&requestCtx);
    }
}

static void fs_C6_getTimeReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo)
{
    SoftwareTestingC6_getTimeProtocolRequestData_t *fullrequest = (SoftwareTestingC6_getTimeProtocolRequestData_t *) fp_DataInfo->pu8Data;
    ReqContext_t requestCtx;

    STATIC_ASSERT_SIZE_CHECK(SoftwareTestingC6_getTimeProtocolRequestData_t);

    if ((fullrequest == NULL) || (pSrvApiHnd == NULL) || (fp_DataInfo->u16DataSize != sizeof(*fullrequest)))
    {
        return;
    }
#ifndef BIG_ENDIAN_PLATFORM
    // no out-arguments specified for response - simple acknowledge call
#else   // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Deserialize response fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    if (pSrvApiHnd->SoftwareTesting_C6_getTimeRequestHandler != NULL)
    {
        requestCtx.nInterfaceNumber = fp_DataInfo->pMACContext->nInterfaceNumber;
        requestCtx.netType = fp_DataInfo->pMACContext->netType;
        requestCtx.nAddr = fp_DataInfo->pMACContext->nSourceAddr;
        requestCtx.seqId = fullrequest->hdr.seqId;

        pSrvApiHnd->SoftwareTesting_C6_getTimeRequestHandler(&requestCtx);
    }
}


/**********************************************************************
 *
 *  Public methods implementation
 *
 **********************************************************************/
void SoftwareTesting_registerServerApi(SoftwareTesting_ServerApi_t *pSrvApiHandlers)
{
    pSrvApiHnd = pSrvApiHandlers;
}

ESSA_pStack_FunctionProtocolInfo_t SoftwareTesting_getServerProtocolDescriptor(void)
{
    return (ESSA_pStack_FunctionProtocolInfo_t) &FP_SoftwareTestingProtocolServerInfo;
}

ESSATMAC_ErrCodes SoftwareTesting_OM1_OpModeResetResp(
                RespContext_t* ctx,
                const SOFTWARETESTING_eOpModes_t eOpMode
)
{
#ifndef BIG_ENDIAN_PLATFORM
    SoftwareTestingOM1_OpModeResetProtocolResponseData_t responseParams;
#else  // #ifndef BIG_ENDIAN_PLATFORM
    uint8_t responseParams[sizeof(SoftwareTestingOM1_OpModeResetProtocolResponseData_t)] = { 0 };
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    ESSATMAC_ErrCodes sendResult = ESSATMAC_EC_NULL;

    STATIC_ASSERT_SIZE_CHECK(SoftwareTestingOM1_OpModeResetProtocolResponseData_t);

    if (ctx != NULL)
    {
#ifndef BIG_ENDIAN_PLATFORM
        // fill message header
        // RS485 wire protocol also uses LE byte order -> serialization of params is not needed
        responseParams.hdr.protoId = ES_SAT_FUNC_PROTOCOL_ID_SOFTWARETESTING;
        responseParams.hdr.funcId  = SOFTWARETESTING_OM1_OPMODERESET_FUNCRESP_ID;
        responseParams.hdr.seqId   = ctx->seqId;
        responseParams.hdr.errCode = ESSA_FP_ERRCODE_NOERROR;
        SET_RESPONSE(responseParams.hdr);

        // fill message data
        responseParams.data.eOpMode = eOpMode;
#else // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Serialize request fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

        sendResult = ESSA_Stack_SendFrameEx((ESSASNetInterface) ctx->nInterfaceNumber,
                                            ctx->netType,
                                            ctx->nAddr,
                                            ES_SAT_MAC_PROTOCOL_ID_FP_LAYER,
#ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) &responseParams,
#else // #ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) responseParams,
#endif // #ifndef BIG_ENDIAN_PLATFORM
                                            sizeof(SoftwareTestingOM1_OpModeResetProtocolResponseData_t),
                                            STACK_SENDFRAME_DEFAULT_PRIO,
                                            (ESSATMAC_DrvResult_Cbk_t) NULL,
                                            (uint32_t *) NULL);
    }

    return sendResult;
}

ESSATMAC_ErrCodes SoftwareTesting_OM2_CommandFloodResp(
                RespContext_t* ctx,
                const SOFTWARETESTING_sCommandCount_t * const sNumOfCommandsRecieved
)
{
#ifndef BIG_ENDIAN_PLATFORM
    SoftwareTestingOM2_CommandFloodProtocolResponseData_t responseParams;
#else  // #ifndef BIG_ENDIAN_PLATFORM
    uint8_t responseParams[sizeof(SoftwareTestingOM2_CommandFloodProtocolResponseData_t)] = { 0 };
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    ESSATMAC_ErrCodes sendResult = ESSATMAC_EC_NULL;

    STATIC_ASSERT_SIZE_CHECK(SoftwareTestingOM2_CommandFloodProtocolResponseData_t);

    if ((ctx != NULL) && (sNumOfCommandsRecieved != NULL))
    {
#ifndef BIG_ENDIAN_PLATFORM
        // fill message header
        // RS485 wire protocol also uses LE byte order -> serialization of params is not needed
        responseParams.hdr.protoId = ES_SAT_FUNC_PROTOCOL_ID_SOFTWARETESTING;
        responseParams.hdr.funcId  = SOFTWARETESTING_OM2_COMMANDFLOOD_FUNCRESP_ID;
        responseParams.hdr.seqId   = ctx->seqId;
        responseParams.hdr.errCode = ESSA_FP_ERRCODE_NOERROR;
        SET_RESPONSE(responseParams.hdr);

        // fill message data
        if (sNumOfCommandsRecieved != NULL)
        {
            responseParams.data.sNumOfCommandsRecieved = *(sNumOfCommandsRecieved);
        }
        else
        {
            (void) memset((void *) &responseParams.data.sNumOfCommandsRecieved,
                          0U,
                          sizeof(responseParams.data.sNumOfCommandsRecieved));
        }
#else // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Serialize request fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

        sendResult = ESSA_Stack_SendFrameEx((ESSASNetInterface) ctx->nInterfaceNumber,
                                            ctx->netType,
                                            ctx->nAddr,
                                            ES_SAT_MAC_PROTOCOL_ID_FP_LAYER,
#ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) &responseParams,
#else // #ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) responseParams,
#endif // #ifndef BIG_ENDIAN_PLATFORM
                                            sizeof(SoftwareTestingOM2_CommandFloodProtocolResponseData_t),
                                            STACK_SENDFRAME_DEFAULT_PRIO,
                                            (ESSATMAC_DrvResult_Cbk_t) NULL,
                                            (uint32_t *) NULL);
    }

    return sendResult;
}

ESSATMAC_ErrCodes SoftwareTesting_C1_CommandVerificationResp(
                RespContext_t* ctx,
                const SOFTWARETESTING_eVerificationModes_t eVerificationModeReturn,
                const SOFTWARETESTING_sCommandCount_t * const sNumOfCommandsRecieved,
                const SOFTWARETESTING_sEchoValue_t * const sEchoReturn
)
{
#ifndef BIG_ENDIAN_PLATFORM
    SoftwareTestingC1_CommandVerificationProtocolResponseData_t responseParams;
#else  // #ifndef BIG_ENDIAN_PLATFORM
    uint8_t responseParams[sizeof(SoftwareTestingC1_CommandVerificationProtocolResponseData_t)] = { 0 };
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    ESSATMAC_ErrCodes sendResult = ESSATMAC_EC_NULL;

    STATIC_ASSERT_SIZE_CHECK(SoftwareTestingC1_CommandVerificationProtocolResponseData_t);

    if ((ctx != NULL) && (sNumOfCommandsRecieved != NULL) && (sEchoReturn != NULL))
    {
#ifndef BIG_ENDIAN_PLATFORM
        // fill message header
        // RS485 wire protocol also uses LE byte order -> serialization of params is not needed
        responseParams.hdr.protoId = ES_SAT_FUNC_PROTOCOL_ID_SOFTWARETESTING;
        responseParams.hdr.funcId  = SOFTWARETESTING_C1_COMMANDVERIFICATION_FUNCRESP_ID;
        responseParams.hdr.seqId   = ctx->seqId;
        responseParams.hdr.errCode = ESSA_FP_ERRCODE_NOERROR;
        SET_RESPONSE(responseParams.hdr);

        // fill message data
        responseParams.data.eVerificationModeReturn = eVerificationModeReturn;
        if (sNumOfCommandsRecieved != NULL)
        {
            responseParams.data.sNumOfCommandsRecieved = *(sNumOfCommandsRecieved);
        }
        else
        {
            (void) memset((void *) &responseParams.data.sNumOfCommandsRecieved,
                          0U,
                          sizeof(responseParams.data.sNumOfCommandsRecieved));
        }
        if (sEchoReturn != NULL)
        {
            responseParams.data.sEchoReturn = *(sEchoReturn);
        }
        else
        {
            (void) memset((void *) &responseParams.data.sEchoReturn,
                          0U,
                          sizeof(responseParams.data.sEchoReturn));
        }
#else // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Serialize request fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

        sendResult = ESSA_Stack_SendFrameEx((ESSASNetInterface) ctx->nInterfaceNumber,
                                            ctx->netType,
                                            ctx->nAddr,
                                            ES_SAT_MAC_PROTOCOL_ID_FP_LAYER,
#ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) &responseParams,
#else // #ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) responseParams,
#endif // #ifndef BIG_ENDIAN_PLATFORM
                                            sizeof(SoftwareTestingC1_CommandVerificationProtocolResponseData_t),
                                            STACK_SENDFRAME_DEFAULT_PRIO,
                                            (ESSATMAC_DrvResult_Cbk_t) NULL,
                                            (uint32_t *) NULL);
    }

    return sendResult;
}

ESSATMAC_ErrCodes SoftwareTesting_C2_InstrumentVerificationResp(
                RespContext_t* ctx,
                const SOFTWARETESTING_eInstrumentOpt_t eInstrumentSelectionReturn,
                const SOFTWARETESTING_eInstrumentPower_t ePowerSelectionReturn,
                const SOFTWARETESTING_sCommandCount_t * const sNumOfCommandsRecieved,
                const SOFTWARETESTING_sEchoValue_t * const sEchoReturn
)
{
#ifndef BIG_ENDIAN_PLATFORM
    SoftwareTestingC2_InstrumentVerificationProtocolResponseData_t responseParams;
#else  // #ifndef BIG_ENDIAN_PLATFORM
    uint8_t responseParams[sizeof(SoftwareTestingC2_InstrumentVerificationProtocolResponseData_t)] = { 0 };
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    ESSATMAC_ErrCodes sendResult = ESSATMAC_EC_NULL;

    STATIC_ASSERT_SIZE_CHECK(SoftwareTestingC2_InstrumentVerificationProtocolResponseData_t);

    if ((ctx != NULL) && (sNumOfCommandsRecieved != NULL) && (sEchoReturn != NULL))
    {
#ifndef BIG_ENDIAN_PLATFORM
        // fill message header
        // RS485 wire protocol also uses LE byte order -> serialization of params is not needed
        responseParams.hdr.protoId = ES_SAT_FUNC_PROTOCOL_ID_SOFTWARETESTING;
        responseParams.hdr.funcId  = SOFTWARETESTING_C2_INSTRUMENTVERIFICATION_FUNCRESP_ID;
        responseParams.hdr.seqId   = ctx->seqId;
        responseParams.hdr.errCode = ESSA_FP_ERRCODE_NOERROR;
        SET_RESPONSE(responseParams.hdr);

        // fill message data
        responseParams.data.eInstrumentSelectionReturn = eInstrumentSelectionReturn;
        responseParams.data.ePowerSelectionReturn = ePowerSelectionReturn;
        if (sNumOfCommandsRecieved != NULL)
        {
            responseParams.data.sNumOfCommandsRecieved = *(sNumOfCommandsRecieved);
        }
        else
        {
            (void) memset((void *) &responseParams.data.sNumOfCommandsRecieved,
                          0U,
                          sizeof(responseParams.data.sNumOfCommandsRecieved));
        }
        if (sEchoReturn != NULL)
        {
            responseParams.data.sEchoReturn = *(sEchoReturn);
        }
        else
        {
            (void) memset((void *) &responseParams.data.sEchoReturn,
                          0U,
                          sizeof(responseParams.data.sEchoReturn));
        }
#else // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Serialize request fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

        sendResult = ESSA_Stack_SendFrameEx((ESSASNetInterface) ctx->nInterfaceNumber,
                                            ctx->netType,
                                            ctx->nAddr,
                                            ES_SAT_MAC_PROTOCOL_ID_FP_LAYER,
#ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) &responseParams,
#else // #ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) responseParams,
#endif // #ifndef BIG_ENDIAN_PLATFORM
                                            sizeof(SoftwareTestingC2_InstrumentVerificationProtocolResponseData_t),
                                            STACK_SENDFRAME_DEFAULT_PRIO,
                                            (ESSATMAC_DrvResult_Cbk_t) NULL,
                                            (uint32_t *) NULL);
    }

    return sendResult;
}

ESSATMAC_ErrCodes SoftwareTesting_C4_CommandExecutionRelativeTimingResp(
                RespContext_t* ctx,
                const SOFTWARETESTING_eCommandExecutionReturn_t eCommandReturn
)
{
#ifndef BIG_ENDIAN_PLATFORM
    SoftwareTestingC4_CommandExecutionRelativeTimingProtocolResponseData_t responseParams;
#else  // #ifndef BIG_ENDIAN_PLATFORM
    uint8_t responseParams[sizeof(SoftwareTestingC4_CommandExecutionRelativeTimingProtocolResponseData_t)] = { 0 };
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    ESSATMAC_ErrCodes sendResult = ESSATMAC_EC_NULL;

    STATIC_ASSERT_SIZE_CHECK(SoftwareTestingC4_CommandExecutionRelativeTimingProtocolResponseData_t);

    if (ctx != NULL)
    {
#ifndef BIG_ENDIAN_PLATFORM
        // fill message header
        // RS485 wire protocol also uses LE byte order -> serialization of params is not needed
        responseParams.hdr.protoId = ES_SAT_FUNC_PROTOCOL_ID_SOFTWARETESTING;
        responseParams.hdr.funcId  = SOFTWARETESTING_C4_COMMANDEXECUTIONRELATIVETIMING_FUNCRESP_ID;
        responseParams.hdr.seqId   = ctx->seqId;
        responseParams.hdr.errCode = ESSA_FP_ERRCODE_NOERROR;
        SET_RESPONSE(responseParams.hdr);

        // fill message data
        responseParams.data.eCommandReturn = eCommandReturn;
#else // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Serialize request fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

        sendResult = ESSA_Stack_SendFrameEx((ESSASNetInterface) ctx->nInterfaceNumber,
                                            ctx->netType,
                                            ctx->nAddr,
                                            ES_SAT_MAC_PROTOCOL_ID_FP_LAYER,
#ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) &responseParams,
#else // #ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) responseParams,
#endif // #ifndef BIG_ENDIAN_PLATFORM
                                            sizeof(SoftwareTestingC4_CommandExecutionRelativeTimingProtocolResponseData_t),
                                            STACK_SENDFRAME_DEFAULT_PRIO,
                                            (ESSATMAC_DrvResult_Cbk_t) NULL,
                                            (uint32_t *) NULL);
    }

    return sendResult;
}

ESSATMAC_ErrCodes SoftwareTesting_C5_CommandExecutionAbsoluteTimingResp(
                RespContext_t* ctx,
                const SOFTWARETESTING_eCommandExecutionReturn_t eCommandReturn
)
{
#ifndef BIG_ENDIAN_PLATFORM
    SoftwareTestingC5_CommandExecutionAbsoluteTimingProtocolResponseData_t responseParams;
#else  // #ifndef BIG_ENDIAN_PLATFORM
    uint8_t responseParams[sizeof(SoftwareTestingC5_CommandExecutionAbsoluteTimingProtocolResponseData_t)] = { 0 };
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    ESSATMAC_ErrCodes sendResult = ESSATMAC_EC_NULL;

    STATIC_ASSERT_SIZE_CHECK(SoftwareTestingC5_CommandExecutionAbsoluteTimingProtocolResponseData_t);

    if (ctx != NULL)
    {
#ifndef BIG_ENDIAN_PLATFORM
        // fill message header
        // RS485 wire protocol also uses LE byte order -> serialization of params is not needed
        responseParams.hdr.protoId = ES_SAT_FUNC_PROTOCOL_ID_SOFTWARETESTING;
        responseParams.hdr.funcId  = SOFTWARETESTING_C5_COMMANDEXECUTIONABSOLUTETIMING_FUNCRESP_ID;
        responseParams.hdr.seqId   = ctx->seqId;
        responseParams.hdr.errCode = ESSA_FP_ERRCODE_NOERROR;
        SET_RESPONSE(responseParams.hdr);

        // fill message data
        responseParams.data.eCommandReturn = eCommandReturn;
#else // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Serialize request fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

        sendResult = ESSA_Stack_SendFrameEx((ESSASNetInterface) ctx->nInterfaceNumber,
                                            ctx->netType,
                                            ctx->nAddr,
                                            ES_SAT_MAC_PROTOCOL_ID_FP_LAYER,
#ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) &responseParams,
#else // #ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) responseParams,
#endif // #ifndef BIG_ENDIAN_PLATFORM
                                            sizeof(SoftwareTestingC5_CommandExecutionAbsoluteTimingProtocolResponseData_t),
                                            STACK_SENDFRAME_DEFAULT_PRIO,
                                            (ESSATMAC_DrvResult_Cbk_t) NULL,
                                            (uint32_t *) NULL);
    }

    return sendResult;
}

ESSATMAC_ErrCodes SoftwareTesting_getCommandExecutionTimingResp(
                RespContext_t* ctx,
                const SOFTWARETESTING_sCommandCount_t * const sNumOfCommandsRecieved,
                const SOFTWARETESTING_sEchoValue_t * const sEchoReturn,
                const SOFTWARETESTING_sdate_t * const sDateCommandReturn,
                const SOFTWARETESTING_stime_t * const sTimeCommandReturn
)
{
#ifndef BIG_ENDIAN_PLATFORM
    SoftwareTestinggetCommandExecutionTimingProtocolResponseData_t responseParams;
#else  // #ifndef BIG_ENDIAN_PLATFORM
    uint8_t responseParams[sizeof(SoftwareTestinggetCommandExecutionTimingProtocolResponseData_t)] = { 0 };
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    ESSATMAC_ErrCodes sendResult = ESSATMAC_EC_NULL;

    STATIC_ASSERT_SIZE_CHECK(SoftwareTestinggetCommandExecutionTimingProtocolResponseData_t);

    if ((ctx != NULL) && (sNumOfCommandsRecieved != NULL) && (sEchoReturn != NULL) && (sDateCommandReturn != NULL) && (sTimeCommandReturn != NULL))
    {
#ifndef BIG_ENDIAN_PLATFORM
        // fill message header
        // RS485 wire protocol also uses LE byte order -> serialization of params is not needed
        responseParams.hdr.protoId = ES_SAT_FUNC_PROTOCOL_ID_SOFTWARETESTING;
        responseParams.hdr.funcId  = SOFTWARETESTING_GETCOMMANDEXECUTIONTIMING_FUNCRESP_ID;
        responseParams.hdr.seqId   = ctx->seqId;
        responseParams.hdr.errCode = ESSA_FP_ERRCODE_NOERROR;
        SET_RESPONSE(responseParams.hdr);

        // fill message data
        if (sNumOfCommandsRecieved != NULL)
        {
            responseParams.data.sNumOfCommandsRecieved = *(sNumOfCommandsRecieved);
        }
        else
        {
            (void) memset((void *) &responseParams.data.sNumOfCommandsRecieved,
                          0U,
                          sizeof(responseParams.data.sNumOfCommandsRecieved));
        }
        if (sEchoReturn != NULL)
        {
            responseParams.data.sEchoReturn = *(sEchoReturn);
        }
        else
        {
            (void) memset((void *) &responseParams.data.sEchoReturn,
                          0U,
                          sizeof(responseParams.data.sEchoReturn));
        }
        if (sDateCommandReturn != NULL)
        {
            responseParams.data.sDateCommandReturn = *(sDateCommandReturn);
        }
        else
        {
            (void) memset((void *) &responseParams.data.sDateCommandReturn,
                          0U,
                          sizeof(responseParams.data.sDateCommandReturn));
        }
        if (sTimeCommandReturn != NULL)
        {
            responseParams.data.sTimeCommandReturn = *(sTimeCommandReturn);
        }
        else
        {
            (void) memset((void *) &responseParams.data.sTimeCommandReturn,
                          0U,
                          sizeof(responseParams.data.sTimeCommandReturn));
        }
#else // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Serialize request fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

        sendResult = ESSA_Stack_SendFrameEx((ESSASNetInterface) ctx->nInterfaceNumber,
                                            ctx->netType,
                                            ctx->nAddr,
                                            ES_SAT_MAC_PROTOCOL_ID_FP_LAYER,
#ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) &responseParams,
#else // #ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) responseParams,
#endif // #ifndef BIG_ENDIAN_PLATFORM
                                            sizeof(SoftwareTestinggetCommandExecutionTimingProtocolResponseData_t),
                                            STACK_SENDFRAME_DEFAULT_PRIO,
                                            (ESSATMAC_DrvResult_Cbk_t) NULL,
                                            (uint32_t *) NULL);
    }

    return sendResult;
}

ESSATMAC_ErrCodes SoftwareTesting_C6_getTimeResp(
                RespContext_t* ctx,
                const uint32_t u32UpTime,
                const SOFTWARETESTING_sdate_t * const sDate,
                const SOFTWARETESTING_stime_t * const sTime
)
{
#ifndef BIG_ENDIAN_PLATFORM
    SoftwareTestingC6_getTimeProtocolResponseData_t responseParams;
#else  // #ifndef BIG_ENDIAN_PLATFORM
    uint8_t responseParams[sizeof(SoftwareTestingC6_getTimeProtocolResponseData_t)] = { 0 };
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    ESSATMAC_ErrCodes sendResult = ESSATMAC_EC_NULL;

    STATIC_ASSERT_SIZE_CHECK(SoftwareTestingC6_getTimeProtocolResponseData_t);

    if ((ctx != NULL) && (sDate != NULL) && (sTime != NULL))
    {
#ifndef BIG_ENDIAN_PLATFORM
        // fill message header
        // RS485 wire protocol also uses LE byte order -> serialization of params is not needed
        responseParams.hdr.protoId = ES_SAT_FUNC_PROTOCOL_ID_SOFTWARETESTING;
        responseParams.hdr.funcId  = SOFTWARETESTING_C6_GETTIME_FUNCRESP_ID;
        responseParams.hdr.seqId   = ctx->seqId;
        responseParams.hdr.errCode = ESSA_FP_ERRCODE_NOERROR;
        SET_RESPONSE(responseParams.hdr);

        // fill message data
        responseParams.data.u32UpTime = u32UpTime;
        if (sDate != NULL)
        {
            responseParams.data.sDate = *(sDate);
        }
        else
        {
            (void) memset((void *) &responseParams.data.sDate,
                          0U,
                          sizeof(responseParams.data.sDate));
        }
        if (sTime != NULL)
        {
            responseParams.data.sTime = *(sTime);
        }
        else
        {
            (void) memset((void *) &responseParams.data.sTime,
                          0U,
                          sizeof(responseParams.data.sTime));
        }
#else // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Serialize request fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

        sendResult = ESSA_Stack_SendFrameEx((ESSASNetInterface) ctx->nInterfaceNumber,
                                            ctx->netType,
                                            ctx->nAddr,
                                            ES_SAT_MAC_PROTOCOL_ID_FP_LAYER,
#ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) &responseParams,
#else // #ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) responseParams,
#endif // #ifndef BIG_ENDIAN_PLATFORM
                                            sizeof(SoftwareTestingC6_getTimeProtocolResponseData_t),
                                            STACK_SENDFRAME_DEFAULT_PRIO,
                                            (ESSATMAC_DrvResult_Cbk_t) NULL,
                                            (uint32_t *) NULL);
    }

    return sendResult;
}


